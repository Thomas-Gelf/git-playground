<?php

namespace IcingaMetrics;

class Defaults
{
    const DOT_DIR = '.icinga-metrics';
}
