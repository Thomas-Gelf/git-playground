<?php

namespace IcingaMetrics;

class Application
{
    public const LOG_NAME = 'icinga-metrics';
    public const PROCESS_NAME = 'IcingaMetrics';
}
