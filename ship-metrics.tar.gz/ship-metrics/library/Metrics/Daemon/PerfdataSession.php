<?php

namespace Icinga\Module\Metrics\Daemon;

use React\Socket\ConnectionInterface;

/**
 * @deprecated
 */
class PerfdataSession
{
    protected $buffer = '';

    protected $listener;

    protected $connection;

    public function __construct(ConnectionInterface $conn, PerfdataListener $listener)
    {
        $this->connection = $conn;
        $this->listener = $listener;
        $conn->on('data', function ($data) use ($listener) {
            $this->handleData($data);
        });
    }

    /**
     * Handles data on a single session.
     *
     * We immediately buffer each single line, this way we can process data in
     * parallel for multiple sessions. Spitting by newline is important, otherwise
     * we could potentially mix half-finished lines of multiple parallel sessions
     *
     * @param $data
     */
    protected function handleData($data)
    {
        $offset = 0;
        if (strlen($this->buffer) > 0) {
            $data = $this->buffer . $data;
        }
        // $newLen = strlen($data);
        while (false !== ($pos = \strpos($data, "\n", $offset))) {
            $line = \substr($data, $offset, $pos - $offset);
            $offset = $pos + 1;
            $this->listener->pushLine($line);
        }

        $this->buffer = \substr($data, $offset);
        if (strlen($this->buffer)) {
            printf("Remaining: %s\n", $this->buffer);
        }
    }

    public function __destruct()
    {
        $this->listener = null;
        $this->connection = null;
    }
}
