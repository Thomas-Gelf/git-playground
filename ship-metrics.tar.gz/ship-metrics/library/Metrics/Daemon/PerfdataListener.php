<?php

namespace Icinga\Module\Metrics\Daemon;

use Clue\React\Mq\Queue;
use Clue\React\Redis\Client as RedisClient;
use Icinga\Application\Logger;
use Icinga\Module\Metrics\Redis\LuaScriptRunner;
use React\EventLoop\LoopInterface;
use React\Socket\ConnectionInterface;
use React\Socket\Server;
use SplObjectStorage;

/**
 * @deprecated -> check whether we need some code, before deleting
 */
class PerfdataListener
{
    /** @var LoopInterface */
    protected $loop;

    /** @var RedisClient */
    protected $redis;

    /** @var \React\EventLoop\TimerInterface[] */
    protected $timers = [];

    /** @var array */
    protected $bufferLines = [];

    /** @var int */
    protected $bufferLineCount = 0;

    /**
     * Periodic flush interval
     *
     * When clients serve large buffers over slow connections, neither reaching
     * $maxBufferLines nor disconnecting over a long time, this makes sure that
     * we flush anyways from time to time.
     *
     * This might also help with connections that died badly without sending a
     * close event
     *
     * @var int
     */
    protected $flushInterval = 3;

    /** @var int A flush is forced once this many lines have been buffered */
    protected $maxBufferLines = 10000;

    /**
     * Arbitrary artificial limit for parallel connections
     *
     * 500 connections shouldn't be a problem, but this component hasn't been
     * designed with the intention to serve lot's of single clients. This limit
     * is in place to tell users in time to re-check our documentation.
     *
     * @var int
     */
    protected $connectionLimit = 500;

    /** @var SplObjectStorage */
    protected $sessions;

    /** @var LuaScriptRunner */
    protected $lua;

    /** @var int Payload bytes received on our connections */
    protected $bytesReceived = 0;

    /** @var int Newline-separated raw received lines */
    protected $linesReceived = 0;

    /** @var int Lines flushed to Redis */
    protected $linesFlushed = 0;

    /** @var int Lines lost when flushing to Redis */
    protected $linesLostOnFlush = 0;

    /** @var int Counter increased on every new Socket connection */
    protected $totalConnects = 0;

    /** @var int Counter increased on every closed Socket connection */
    protected $totalDisconnects = 0;

    /** @var int Counter increased on every flush to Redis */
    protected $flushes = 0;

    protected $linesWaitingForRedis = 0;

    protected $redisRequestsPending = 0;

    protected $paused = false;

    protected $shownStats;

    /** @var Queue */
    protected $redisQueue;

    protected $host;

    protected $port;

    public function __construct(RedisClient $redis, $host, $port)
    {
        $this->redis = $redis;
        $this->host = $host;
        $this->port = $port;
        $this->lua = new LuaScriptRunner($this->redis);
    }

    protected function getSocket()
    {
        return $this->host . ':' . $this->port;
    }

    public function run(LoopInterface $loop)
    {
        $this->loop = $loop;
        $this->redisQueue = new Queue(1, null, function ($bulk) {
            return $this->lua->runAsyncScript('pushPerfdata', [$bulk]);
        });
        $context = ['tcp' => [
            // 'backlog'      => 200,
            // 'so_reuseport' => true,
            // 'ipv6_v6only'  => true
        ]];
        if (PHP_VERSION_ID >= 70000) {
            // $context['tcp']['so_reuseport'] = true;
        }
        $socket = new Server($this->getSocket(), $this->loop, $context);
        $this->sessions = new SplObjectStorage();
        $this->initializeTimer();
        Logger::info("Starting Perfdata listener on " . $this->getSocket());
        $socket->on('connection', function (ConnectionInterface $connection) {
            $this->onConnection($connection);
        });
//        $socket->on('connection', [$this, 'onConnection']);
    }

    protected function onConnection(ConnectionInterface $connection)
    {
        $this->totalConnects++;
        if ($this->paused) {
            $connection->pause();
        }
        $this->sessions->attach($connection);
        Logger::debug('Perfdata listener got a connection from ' . $connection->getRemoteAddress());
        $session = new PerfdataSession($connection, $this);
        $connection->on('close', function () use ($session, $connection) {
            $this->totalDisconnects++;
            Logger::debug('Perfdata closing session for ' . $connection->getRemoteAddress());
            unset($session);
            if ($this->sessions) {
                $this->sessions->detach($connection);
            }

            // Process the buffer. It's usually empty at this stage, but
            // there might be failed connections. Let's flush.
            $this->processBuffer();
        });
    }

    public function getLoop()
    {
        return $this->loop;
    }

    public function getStats()
    {
        return [
            'connects'          => $this->totalConnects,
            'disconnects'       => $this->totalDisconnects,
            'bytesReceived'     => $this->bytesReceived,
            'linesReceived'     => $this->linesReceived,
            'linesFlushed'      => $this->linesFlushed,
            'linesLostOnFlush'  => $this->linesLostOnFlush,
            'activeConnections' => \count($this->sessions),
            'linesWaitingForRedis' => $this->linesWaitingForRedis,
            'redisRequestsPending' => $this->redisRequestsPending,
            'bufferedLines'     => \count($this->bufferLines),
        ];
    }

    protected function sendStats()
    {
        $stats = $this->getStats();
        if ($stats !== $this->shownStats) {
            // print_r($stats);
            $this->shownStats = $stats;
        }
        $raw = 'PerfdataListener';
        $noCounters = [
            'activeConnections',
            'linesWaitingForRedis',
            'bufferedLines',
            'redisRequestsPending',
        ];
        foreach ($stats as $key => $value) {
            if (! in_array($key, $noCounters)) {
                $value .= 'c';
            }
            $raw .= " $key=${value}";
        }
        $raw .= ' ' . time();

        // $this->pushInfluxDbLineFormat($raw);
        // $this->pushLine($raw);
    }

    public function stop()
    {
        $this->stopTimers();
        $this->tearDownAllSessions();
        $this->processBuffer();

        $this->loop = null;
    }

    protected function tearDownAllSessions()
    {
        if ($this->sessions) {
            /** @var ConnectionInterface $session */
            foreach ($this->sessions as $session) {
                $session->end();
            }
            $this->sessions = null;
        }
    }

    protected function pauseAllSessions()
    {
        if (! $this->paused && $this->sessions) {
            printf("Pausing %d sessions\n", $this->sessions->count());
            /** @var ConnectionInterface $session */
            foreach ($this->sessions as $session) {
                $session->pause();
            }
            $this->paused = true;
        }
    }

    protected function resumeAllSessions()
    {
        if ($this->paused && $this->sessions) {
            printf("Resuming %d sessions\n", $this->sessions->count());
            /** @var ConnectionInterface $session */
            foreach ($this->sessions as $session) {
                $session->resume();
            }
            $this->paused = false;
        }
    }

    protected function initializeTimer()
    {
        $this->timers[] = $this->loop->addPeriodicTimer($this->flushInterval, function () {
            $this->processBuffer();
        });
        $this->timers[] = $this->loop->addPeriodicTimer(1, function () {
            $this->sendStats();
        });
    }

    protected function stopTimers()
    {
        foreach ($this->timers as $timer) {
            $this->loop->cancelTimer($timer);
        }

        $this->timers = [];
    }

    /**
     * Buffer the given line. Flush when $maxBufferLines are reached
     *
     * Usually called by InfluxDbSession after each single line
     *
     * @param $line
     * @return $this
     */
    public function pushLine($line)
    {
        $this->bufferLines[] = $line;
        $this->bufferLineCount++;
        $this->linesReceived++;
        if ($this->bufferLineCount === $this->maxBufferLines) {
            printf("Perfdata Listener reached %s buffer lines, processing\n", $this->maxBufferLines);
            $this->processBuffer();
        }

        return $this;
    }

    /**
     * Send the buffer to Redis
     *
     * While runAsyncScript returns a promise, we currently to not care. This
     * means that data will be lost without notice when the request fails. We
     * could eventually track pending chunks and drain/block the incoming
     * connections in such scenario. However, I'm not sure whether this would
     * be the best solution.
     */
    public function processBuffer()
    {
        $count = $this->bufferLineCount;
        print("processBuffer($count)\n");
        if ($count === 0) {
            if ($this->paused) {
                $this->resumeAllSessions();
            }
            return;
        }
        if ($this->redisRequestsPending > 10000000) {
            printf(
                "There are still %d requests and %d lines waiting for Redis, checking again in 0.2s\n",
                $this->redisRequestsPending,
                $this->linesWaitingForRedis
            );
            if (! $this->paused) {
                $this->pauseAllSessions();
            }
            $this->loop->addTimer(0.05, function () {
                $this->processBuffer();
            });

            return;
        } elseif ($this->paused) {
            $this->resumeAllSessions();
        }

        $this->sendBufferToRedis();
    }

    protected function sendBufferToRedis()
    {
        foreach (array_chunk($this->bufferLines, 1000, false) as $chunk) {
            $data = \implode("\n", $chunk) . "\n";
            $this->sendBlobToRedis($data, \count($chunk));
        }

        $this->bufferLines = [];
        $this->bufferLineCount = 0;
    }

    protected function sendBlobToRedis($data, $count)
    {
        Logger::info("Perfdata: pushing $count buffer lines to redis");
        $q = $this->redisQueue;
        $q($data, $count);
    }

    public function __destruct()
    {
        $this->stop();
    }
}
