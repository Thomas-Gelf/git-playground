<?php

namespace Icinga\Module\Metrics\ProvidedHook;

use gipfl\IcingaWeb2\Icon;
use gipfl\IcingaWeb2\Link;
use gipfl\RrdTool\RrdInfo;
use gipfl\Translation\TranslationHelper;
use gipfl\ZfDb\Adapter\Pdo\PdoAdapter;
use gipfl\ZfDb\Select;
use Icinga\Application\Hook\GrapherHook;
use Icinga\Application\Icinga;
use Icinga\Module\Metrics\Async\Infrastructure;
use Icinga\Module\Metrics\Db\DbFactory;
use Icinga\Module\Metrics\Db\RrdFileInfoLoader;
use Icinga\Module\Metrics\Template\TemplateFinder;
use Icinga\Module\Monitoring\Object\MonitoredObject;
use Icinga\Module\Monitoring\Object\Service;
use Icinga\Module\Metrics\Web\Widget\RrdImg;
use ipl\Html\Html;
use ipl\Html\HtmlDocument;
use Ramsey\Uuid\Uuid;
use Ramsey\Uuid\UuidInterface;

class Grapher extends GrapherHook
{
    use TranslationHelper;

    protected $hasPreviews = true;
    protected PdoAdapter $db;

    protected function init()
    {
        $this->db = DbFactory::db();
    }

    public function has(MonitoredObject $object): bool
    {
        if ($object instanceof Service) {
            // TODO: Template etc...
            return false;
        }
        if ($this->getCiUuid($object) === null) {
            return false;
        } else {
            return true;
        }
    }

    public function getPreviewHtml(MonitoredObject $object)
    {
        return $this->getPreview($object, 560, 240);
    }

    protected function getPreview(MonitoredObject $object, $width, $height)
    {
        if (! $object->process_perfdata) {
            return '';
        }

        $ci = $this->db->fetchRow($this->prepareObjectQuery($object, '*'));
        if (! $ci) {
            return '';
        }

        $loader = new RrdFileInfoLoader($this->db);
        $uuid = $this->db->fetchOne(
            $this->db->select()->from('rrd_file', 'uuid')->where('ci_uuid = ?', $ci->uuid)
        );
        if (! is_string($uuid)) {
            return '';
        }
        $uuid = Uuid::fromBytes($uuid);

        return $this->getPreviewImg($uuid, $loader->load($uuid), $this->db, 'hours25', $width, $height);
    }

    protected function getPreviewImg(UuidInterface $uuid, RrdInfo $info, PdoAdapter $db, $view, $width, $height)
    {
        $url = Icinga::app()->getRequest()->getUrl();
        $views = [
            // 'year'    => 86400 * 365,
            // 'month'   => 86400 * 31,
            // 'week'    => 86400 * 7,
            'hours25' => 3600 * 5,
            // 'hours4'  => 3600 * 4,
        ];
        $end = floor(time() / 60) * 60;
        $start = $url->getParam('metricStart', $end - $views[$view]);
        $end = $url->getParam('metricEnd', $end);
        $doc = new HtmlDocument();
        if ($templates = TemplateFinder::findTemplate($info)) {
            $cnt = 0;
            foreach ($templates as $template) {
                $cnt++;
                $img = new RrdImg($info->getFilename(), $template, $width, $height, [
                    // 'disableCached' => true,
                    'onlyGraph' => $height < 100,
                    'start' => $start,
                    'end'   => $end,
                ]);
                $img->loadImmediately(Infrastructure::remoteClient($db), Infrastructure::loop(), true);
                $doc->add($this->imgContainer($img, $width, $uuid));
            }
        } else {
            $cnt = 0;
            foreach ($info->listDsNames() as $ds) {
                $cnt++;
                $img = new RrdImg($info->getFilename(), 'default', $width, $height, [
                    // 'disableCached' => true,
                    'ds'    => $ds,
                    'smoke' => true,
                    'start' => $start,
                    'end'   => $end,
                ]);
                $img->loadImmediately(Infrastructure::remoteClient($db), Infrastructure::loop(), true);
                $doc->add($this->imgContainer($img, $width, $uuid));
            }
        }

        return $doc;
    }

    protected function imgContainer($img, $width, UuidInterface $uuid)
    {
        return Html::tag('div', [
            'class' => 'icinga-module module-metrics',
            'style' => 'position: relative'
        ], [
            Html::tag('div', [
                'style' => sprintf(
                    'text-align: right; position: absolute; z-index: 5; top: 0.5em; width: %dpx;',
                    $width
                ),
            ], [
                Link::create(Icon::create('zoom-in'), 'metrics/rra/graph', [
                    'uuid' => $uuid->toString()
                ], [
                    'title' => $this->translate('Zoom in'),
                ]),
            ]),
            $img
        ]);
    }

    protected function getCiUuid(MonitoredObject $object): ?UuidInterface
    {
        $uuid = $this->db->fetchOne($this->prepareObjectQuery($object, $object->host_name));
        if ($uuid === false) {
            return null;
        }

        return Uuid::fromBytes($uuid);
    }

    protected function prepareObjectQuery(MonitoredObject $object, $columns): Select
    {
        $query = $this->db->select()
            ->from('ci', $columns)
            ->where('hostname = ?', $object->host_name);
        if ($object instanceof Service) {
            $query->where('subject = ?', $object->service_description);
        }

        return $query;
    }
}
