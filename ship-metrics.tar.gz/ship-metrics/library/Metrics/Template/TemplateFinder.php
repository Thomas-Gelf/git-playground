<?php

namespace Icinga\Module\Metrics\Template;

use gipfl\RrdTool\RrdInfo;

class TemplateFinder
{
    protected static array $candidates = [
        'cpu' => [
            'irq',
            'user',
            'softirq',
            'system',
            'guest',
            'iowait',
            'guest_nice',
            'steal',
            'idle',
            'nice',
        ],
        'ido' => [
            'queries',
            'pending_queries'
        ],
        'interface' => [
            'rxBytes',
            'txBytes',
        ],
        'ointerface' => [
            'inOctets',
            'outOctets',
        ],
        'load' => [
            'load1',
            'load5',
            'load15',
        ],
        'VmwareDiskSeeks' => [
            'smallSeeks',
            'mediumSeeks',
            'largeSeeks',
        ],
        'VmwareDiskReadWrites' => [
            'numberReadAveraged',
            'numberWriteAveraged',
        ],
        'RRDCacheDUpdates' => [
            'UpdatesReceived',
            'DataSetsWritten',
            'UpdatesWritten',
        ],
        'RRDHealth' => [
            'Succeeded',
            'Invalid',
            'Deferred',
        ]
    ];

    public static function findTemplate(RrdInfo $info): ?array
    {
        $ds = $info->getDsList();
        $names = $ds->listNames();
        $matches = [];
        foreach (self::$candidates as $name => $candidate) {
            if (empty(array_diff($candidate, $names))) {
                $matches[] = $name;
            }
        }
        if (! empty($matches)) {
            return $matches;
        }

        return null;
    }
}
