<?php

namespace Icinga\Module\Metrics\Template;

class RrdQueueProcessing extends RrdTemplate
{
    public $legend = [
        'Invalid'   => '#F96266',
        'Deferred'  => '#7A64C8',
        'Succeeded' => '#44bb77',
    ];
}
