<?php

namespace Icinga\Module\Metrics\Cli;

use Clue\React\Redis\Factory as RedisFactory;
use Clue\React\Redis\StreamingClient;
use gipfl\RrdTool\RrdCached\Client as RrdCachedClient;
use gipfl\RrdTool\Rrdtool;
use Icinga\Application\Logger;
use Icinga\Cli\Command as CliCommand;
use Icinga\Module\Metrics\Async\Async;

abstract class Command extends CliCommand
{
    use Async;

    protected $rrdCached;

    protected $redis;

    protected $rrdtool;

    protected $basedir = '/var/lib/icingaweb2/rrd';
    // protected $basedir = '/shared/containers/web/rrd';

    // TODO:
    // protected $baseDir = '/var/lib/icingaweb2/rrd/instance1';

    public function init()
    {
        $this->app->getModuleManager()->loadEnabledModules();
    }

    /**
     * TODO: redis MUST fail loudly
     *
     * @param null $name
     * @return \React\Promise\PromiseInterface
     */
    protected function redisClient($name = null)
    {
        if ($this->redis === null) {
            $factory = new RedisFactory($this->loop());
            $socket = $this->basedir . '/redis/redis.sock';

            $this->redis = $factory->createClient('redis+unix://' . $socket)
                ->then(function (StreamingClient $client) use ($name) {
                    $client->on('end', function () {
                        Logger::info('Redis ended');
                    });
                    $client->on('error', function (\Exception $e) {
                         Logger::error('Redis error: ' . $e->getMessage());
                    });

                    $client->on('close', function () {
                        Logger::info('Redis closed');
                    });

                    if ($name !== null) {
                        try {
                            $client->client('setname', $name)->then(function () use ($name) {
                                Logger::info('Redis client name is now ' . $name);
                            })->otherwise(function (\Exception $e) {
                                printf("Unable to set my name: %s\n", $e->getMessage());
                            });
                        } catch (\Exception $e) {
                            printf("Unable to set my name: %s\n", $e->getMessage());
                        }
                    }

                    return $client;
                }, function (\Exception $e) {
                    Logger::error($e->getMessage());
                });
        }

        return $this->redis;
    }

    protected function rrdCached()
    {
        if ($this->rrdCached === null) {
            $this->rrdCached = new RrdCachedClient(
                $this->basedir . '/rrdcached.sock',
                $this->loop()
            );
        }

        return $this->rrdCached;
    }

    protected function rrdtool()
    {
        if ($this->rrdtool === null) {
            // TODO: This has to be replaced with the new async rrdtool
            $basedir = $this->basedir;
            $binary = '/opt/icinga/rrdtool/bin/rrdtool';
            $binary = '/usr/bin/rrdtool';
            $this->rrdtool = new Rrdtool("$basedir/data", $binary, "$basedir/rrdcached.sock");
        }

        return $this->rrdtool;
    }
}
