<?php

namespace Icinga\Module\Metrics;

class Ci
{
    protected ?string $hostname;
    protected ?string $subject;
    protected ?string $instance;

    public function __construct(?string $hostname, ?string $subject, ?string $instance)
    {
        $this->hostname = $hostname;
        $this->subject = $subject;
        $this->instance = $instance;
    }

    public function getHostname(): ?string
    {
        return $this->hostname;
    }

    public function getSubject(): ?string
    {
        return $this->subject;
    }

    public function getInstance(): ?string
    {
        return $this->instance;
    }
}
