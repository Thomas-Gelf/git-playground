<?php

namespace Icinga\Module\Metrics\Async;

use gipfl\ZfDb\Adapter\Pdo\PdoAdapter;
use Icinga\Module\Metrics\Daemon\RemoteClient;
use Ramsey\Uuid\Uuid;
use Ramsey\Uuid\UuidInterface;
use React\EventLoop\Factory as Loop;
use React\EventLoop\LoopInterface;
use function Clue\React\Block\await;

class Infrastructure
{
    protected static ?RemoteClient $remoteClient = null;
    protected static ?LoopInterface $loop = null;

    public static function getMetricStoreUuid(PdoAdapter $db): UuidInterface
    {
        return Uuid::fromBytes(
            $db->fetchOne($db->select()->from('metric_store', 'uuid')->where('label = ?', 'benchmark'))
        );
    }

    public static function remoteClient(PdoAdapter $db): RemoteClient
    {
        if (self::$remoteClient === null) {
            self::$remoteClient = new RemoteClient(static::getSocketPath($db), static::loop());
        }

        return self::$remoteClient;
    }

    /**
     * @param PdoAdapter $db
     * @param string $method
     * @param $params
     * @return mixed|null
     * @throws \Exception
     */
    public static function syncRpcCall(PdoAdapter $db, string $method, $params)
    {
        $promise = static::remoteClient($db)->request($method, $params);

        return await($promise, static::loop(), 30);
    }

    public static function getSocketPath(PdoAdapter $db): string
    {
        return sprintf(
            '/run/icinga-metrics/%s.sock',
            self::getMetricStoreUuid($db)->toString()
        );
    }

    public static function loop(): LoopInterface
    {
        // Hint: we're not running this loop right now
        if (self::$loop === null) {
            self::$loop = Loop::create();
        }

        return self::$loop;
    }
}
