<?php

namespace Icinga\Module\Metrics\Db;

use gipfl\ZfDb\Adapter\Pdo\PdoAdapter;
use Icinga\Application\Config;

class DbFactory
{
    public static function db(): PdoAdapter
    {
        $config = Config::app('resources')->getSection(Config::module('metrics')->get('db', 'resource'));
        $db = ZfDbConnectionFactory::connection($config->toArray());
        assert($db instanceof PdoAdapter);

        return $db;
    }
}
