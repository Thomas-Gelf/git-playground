<?php

namespace Icinga\Module\Metrics\Redis;

use function array_shift;

/**
 * @deprecated
 */
class RedisUtil
{
    /**
     * Transform [key1, val1, key2, val2] into {key1 => val1, key2 => val2}
     *
     * @param $data
     * @return object
     */
    public static function makeHash($data)
    {
        $hash = (object) [];
        while (null !== ($key = array_shift($data))) {
            $hash->$key = array_shift($data);
        }

        return $hash;
    }
}
