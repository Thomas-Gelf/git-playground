<?php

namespace Icinga\Module\Metrics\Redis;

use Clue\React\Redis\Client;
use Exception;
use Icinga\Application\Logger;
use InvalidArgumentException;
use Predis\Response\ServerException;
use RuntimeException;
use function array_key_exists;
use function call_user_func_array;
use function dirname;
use function file_exists;
use function file_get_contents;
use function preg_match;
use function preg_replace_callback;
use function React\Promise\reject;
use function sprintf;

/**
 * @deprecated
 */
class LuaScriptRunner
{
    protected Client $predis;
    protected string $basedir;
    protected array $files = [];
    protected array $checkSums = [];
    protected array $required = [];

    public function __construct(Client $predis, $basedir = null)
    {
        $this->predis = $predis;
        if ($basedir === null) {
            $this->basedir = $this->detectBaseDir();
        } else {
            $this->basedir = $basedir;
        }
    }

    protected function detectBaseDir(): string
    {
        return dirname(dirname(dirname(__DIR__))) . '/application/luascripts';
    }

    public function __call($funcName, $arguments)
    {
        $this->required = [];
        $keys = $arguments[0] ?? [];
        $args = $arguments[1] ?? [];

        return $this->runScript($funcName, $keys, $args);
    }

    protected function replaceRequire($matches)
    {
        $package = $matches[3];
        if (isset($this->required[$package])) {
            return '';
        } else {
            $script = $this->getScript($package);
            $this->required[$package] = true;

            return $script;
        }
    }

    protected function loadFile($name)
    {
        // Well... lib-dir-Handling is hacky...
        $this->assertValidFileName($name);
        $filename = sprintf('%s/%s.lua', $this->basedir, $name);
        if (file_exists($filename)) {
            return file_get_contents($filename);
        } else {
            $filename = sprintf('%s/lib/%s.lua', $this->basedir, $name);
            if (file_exists($filename)) {
                return file_get_contents($filename);
            } else {
                throw new RuntimeException(sprintf(
                    'Cannot load lua script "%s"',
                    $name
                ));
            }
        }
    }

    protected function assertValidFileName($name)
    {
        if (! preg_match('/^(?:lib\/)?[a-z0-9]+$/i', $name)) {
            throw new InvalidArgumentException(
                'Trying to access invalid lua script: %s',
                $name
            );
        }
    }

    protected function redisFunc($funcName, $params)
    {
        return call_user_func_array([$this->predis, $funcName], $params);
    }

    protected function asyncRedisFunc($funcName, $params)
    {
        return call_user_func_array([$this->predis, $funcName], $params);
    }

    protected function getScript($name)
    {
        if (! array_key_exists($name, $this->files)) {
            $this->files[$name] = $this->loadScript($name);
        }

        return $this->files[$name];
    }

    protected function loadScript($name)
    {
        return preg_replace_callback(
            '/^(\s*require\(\s*)([\'"])((?:lib\/)?[a-z0-9]+)(\2\s*\);?)/mi',
            [$this, 'replaceRequire'],
            $this->loadFile($name)
        );
    }

    protected function getScriptChecksum($name)
    {
        if (! array_key_exists($name, $this->checkSums)) {
            $this->checkSums[$name] = sha1(
                $this->getScript($name)
            );

            // Debug for errors:
            if (false) {
                $a = 0;
                \printf("Script %s (%s):\n", $name, $this->checkSums[$name]);
                foreach (\preg_split('/\n/', $this->getScript($name)) as $line) {
                    \printf("%d: %s\n", ++$a, $line);
                }
            }
        }

        return $this->checkSums[$name];
    }

    /**
     * @param $name
     * @param array $keys
     * @param array $args
     * @param bool $firstTime
     * @return \React\Promise\ExtendedPromiseInterface
     */
    public function runAsyncScript($name, $keys = [], $args = [], $firstTime = true)
    {
        try {
            $checksum = $this->getScriptChecksum($name);
            $params = [$checksum, count($keys)];
            $params = \array_merge($params, array_merge($keys, $args));
        } catch (Exception $e) {
            return reject($e);
        }

        return $this->asyncRedisFunc('evalsha', $params)->otherwise(function (Exception $e) use (
            $name,
            $checksum,
            $params,
            &$firstTime
        ) {
            if (\strpos($e->getMessage(), 'NOSCRIPT') !== false) {
                if ($firstTime) {
                    $firstTime = false;
                } else {
                    throw $e;
                }
                Logger::info(
                    'No SCRIPT with SHA1 == %s, pushing %s.lua',
                    $checksum,
                    $name
                );

                $params[0] = $this->getScript($name);

                return $this->asyncRedisFunc('eval', $params);
            } else {
                return reject($e);
            }
        });
    }

    public function runScript($name, $keys = [], $args = [])
    {
        $checksum = $this->getScriptChecksum($name);
        $params = [$checksum, count($keys)];
        $params = \array_merge($params, \array_merge($keys, $args));

        try {
            $result = $this->redisFunc('evalsha', $params);
        } catch (ServerException $e) {
            if (strpos($e->getMessage(), 'NOSCRIPT') !== false) {
                Logger::info(
                    'No SCRIPT with SHA1 == %s, pushing %s.lua',
                    $checksum,
                    $name
                );

                $params[0] = $this->getScript($name);
                $result = $this->redisFunc('eval', $params);
            } else {
                throw $e;
            }
        }

        return $result;
    }
}
