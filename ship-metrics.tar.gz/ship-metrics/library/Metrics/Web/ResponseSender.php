<?php

namespace Icinga\Module\Metrics\Web;

use gipfl\RrdTool\Rendering\ErrorImage;
use Icinga\Web\Response;
use RuntimeException;
use function gmdate;
use function gzcompress;
use function json_encode;
use function strlen;
use function time;

class ResponseSender
{
    /** @var Response */
    protected $response;

    protected $useXhr = false;

    public function __construct(Response $response)
    {
        $this->response = $response;
    }

    public function useXhr($xhr = true)
    {
        $this->useXhr = $xhr;
    }

    public function sendAsJson($props)
    {
        $response = $this->response;
        // TODO: Check request, Accept-Encoding: gzip, deflate, br
        // $response->setHeader('Content-Encoding', 'gzip', true);
        // $compressed = gzcompress(json_encode($props), -1, ZLIB_ENCODING_GZIP);
        $response->setHeader('Content-Type', 'application/json', true);
        $response->setHeader('Content-Encoding', 'deflate', true);
        $compressed = gzcompress(json_encode($props), -1, ZLIB_ENCODING_DEFLATE);
        $response->setHeader('Content-Length', strlen($compressed), true);
        if ($compressed === false) {
            throw new RuntimeException('Failed to compress img');
        } else {
            echo $compressed;
        }
    }

    public function sendError($error, $width, $height)
    {
        $this->response->setHeader('Content-Type', 'image/png', true);
        $image = new ErrorImage($error);
        // $image->showStackTrace();
        $this->sendNoCacheHeaders();
        if ($this->useXhr) {
            $this->sendAsJson($image->renderToJson($width, $height));
        } else {
            $this->sendImage($image->render($width, $height), 'png');
        }
    }

    public function sendImage($image, $type, $downloadFilename = null)
    {
        $this->sendCacheHeaders();
        $this->response->setHeader('Content-Type', $type, true);
        if ($downloadFilename) {
            $this->response
                ->setHeader('Content-Description', 'File Transfer', true)
                ->setHeader('Content-Disposition', "attachment; filename=\"$downloadFilename\"", true);
        }

        echo $image;
    }

    protected function sendCacheHeaders()
    {
        $secondsToCache = 3600;
        $ts = gmdate("D, d M Y H:i:s", time() + $secondsToCache) . " GMT";
        $this->response
            ->setHeader('Expires', $ts, true)
            ->setHeader('Pragma', 'cache', true)
            ->setHeader('Cache-Control', "public,max-age=$secondsToCache", true);
    }

    protected function sendNoCacheHeaders()
    {
        $this->response
            ->setHeader('Pragma', 'no-cache', true)
            ->setHeader('Cache-Control', 'no-store', true);
    }
}
