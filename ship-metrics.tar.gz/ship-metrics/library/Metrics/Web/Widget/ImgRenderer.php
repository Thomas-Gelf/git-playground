<?php

namespace Icinga\Module\Metrics\Web\Widget;

use gipfl\RrdTool\Graph\Instruction\Shift;
use gipfl\RrdTool\GraphTemplate\TemplateLoader;
use gipfl\RrdTool\RrdGraph;
use ipl\Html\Html;
use Icinga\Date\DateFormatter;
use Icinga\Util\Format;
use Icinga\Web\UrlParams;

class ImgRenderer
{
    /** @var UrlParams */
    protected $params;

    protected $lastGraph;

    protected $knownBooleans = [
        'onlyWhite',
        'onlyBlack',
        'showMissingOnTop'
    ];

    protected $allowedParams = [
        'shift',
        'max',
        'min'
    ];

    public static function fromUrlParams(UrlParams $params)
    {
        $self = new static;
        $self->params = $params;

        return $self;
    }

    public function getWidth()
    {
        return $this->params->get('width', 1200);
    }

    public function getHeight()
    {
        return $this->params->get('height', 120);
    }

    public function getFormat()
    {
        return $this->params->get('format', 'svg');
    }

    public function getCommandString()
    {
        return $this->prepareRrdGraph()->getCommandString(true);
    }

    public function getTemplateName()
    {
        return $this->params->get('template');
    }

    public function getStart()
    {
        return (int) $this->params->get('start', $this->getEnd() - 7200);
    }

    public function getEnd()
    {
        $defaultEnd = floor(time() / 60) * 60;
        return (int) $this->params->get('end', $defaultEnd);
    }

    public function getDisabledDataSources()
    {
        if ($ds = $this->params->get('disableDatasources')) {
            $ds = preg_split('/\s*,\s*/', $ds, -1, PREG_SPLIT_NO_EMPTY);
            return $ds;
        } else {
            return [];
        }
    }

    public function hasDisabledDataSources()
    {
        $disable = $this->params->get('disableDatasources');
        return $disable !== null && \strlen($disable) > 0;
    }

    public function wantsSmoke()
    {
        return (bool) $this->params->get('smoke');
    }

    public function getMaxPercentile()
    {
        return $this->params->get('maxPercentile');
    }

    public function getOnlyGraph()
    {
        return (bool) $this->params->get('onlyGraph');
    }

    public function hasTimeShift()
    {
        $shift = $this->params->get('shift');
        return $shift !== null && \strlen($shift) > 0;
    }

    public function getTimeShift()
    {
        return $this->params->get('shift');
    }

    public function getFileName()
    {
        return $this->params->get('file');
    }

    public function getDs()
    {
        return $this->params->get('ds');
    }

    public function getRra()
    {
        return $this->params->get('rra');
    }

    protected function prepareRrdGraph(): RrdGraph
    {
        $graph = new RrdGraph();
        $graph->setStart($this->getStart());
        $graph->setEnd($this->getEnd());
        $graph->setFormat($this->getFormat());
        $graph->setWidth($this->getWidth());
        $graph->setHeight($this->getHeight());
        $graph->setOnlyGraph($this->getOnlyGraph());

        if ($this->hasTimeShift()) {
            $graph->add(new Shift('timeShift', $this->getTimeShift()));
        }
        if ($this->params->get('disableCached')) {
            $graph->disableCached();
        }

        // $graph->setDarkTheme();
        $this->loadTemplate()->applyToGraph($graph);
        $this->lastGraph = $graph;

        return $graph;
    }

    public function getLastGraph(): RrdGraph
    {
        return $this->lastGraph;
    }

    public function loadTemplate()
    {
        $template = $this->getTemplateName();

        $filename = $this->getFileName();

        $params = [
            'file'     => $filename,
            'height'   => $this->getHeight(),
            'width'    => $this->getWidth(),
            'format'   => $this->getFormat(),
            'start'    => $this->getStart(),
            'end'      => $this->getEnd(),
            'template' => $template,
            'rra'      => $this->getRra(),
            'ds'       => $this->getDs(),
        ];
        if ($this->hasDisabledDataSources()) {
            $params['disableDatasources'] = $this->getDisabledDataSources();
        }
        foreach ($this->knownBooleans as $boolean) {
            if ($this->params->get($boolean)) {
                $params[$boolean] = true;
            }
        }
        foreach ($this->allowedParams as $allowedParam) {
            if ($value = $this->params->get($allowedParam)) {
                $params[$allowedParam] = $value;
            }
        }
        if ($this->wantsSmoke()) {
            $params['smoke'] = true;
            $showMaxPercentile = $this->params->get('maxPercentile');
            if ($showMaxPercentile === null) {
                $showMaxPercentile = 100;
            }
            $params['maxPercentile'] = $showMaxPercentile;
        }
        $loader = new TemplateLoader();
        $template = $loader->load($template, $filename);
        $template->setParams($params);

        return $template;
    }

    protected function addExtraInfos($props)
    {
        if (isset($props->print->Transmitted)) {
            $p = $props->print;
            $props->title = Html::tag('p', [
                'class' => 'information'
            ], Html::sprintf(
                'Received %s, transmitted %s in %s',
                Format::bytes($p->Received),
                Format::bytes($p->Transmitted),
                DateFormatter::formatDuration(
                    $props->graph->end - $props->graph->start
                )
            ))->render();
        }
    }
}
