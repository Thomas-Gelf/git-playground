<?php

namespace Icinga\Module\Metrics\Web\Widget;

use Icinga\Module\Metrics\ExtendedRrdInfo;
use ipl\Html\Html;
use Icinga\Module\Metrics\Template\RrdQueueProcessing;

class InterfaceMetrics extends BunchOfImages
{
    /** @var ExtendedRrdInfo[] */
    protected array $infos;

    /**
     * @param ExtendedRrdInfo[] $infos
     */
    public function __construct(array $infos)
    {
        $this->infos = $infos;
    }

    protected function assemble()
    {
        /** @var ExtendedRrdInfo $info */
        foreach ($this->infos as $info) {
            $this->addTitle("Network Interface: " . $info->getCi()->getInstance(), 'chart-line');
            $this->add(new RrdLegend(new RrdQueueProcessing())); // TODO: LEGEND
            $this->add(Html::tag('div', [
                'style' => 'width: 18em; display: inline-block;'
            ], [
                $this->linkToFile(
                    $info,
                    new RrdImg($info->getFilename(), 'interface', 440, 180)
                )
            ]));
        }
    }
}
