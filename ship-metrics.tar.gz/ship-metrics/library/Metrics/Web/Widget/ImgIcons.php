<?php

namespace Icinga\Module\Metrics\Web\Widget;

use gipfl\Translation\TranslationHelper;
use gipfl\IcingaWeb2\Icon;
use gipfl\IcingaWeb2\Link;
use gipfl\IcingaWeb2\Url;
use ipl\Html\HtmlElement;

class ImgIcons
{
    use TranslationHelper;

    /** @var Url */
    protected $url;

    /** @var string */
    protected $file;

    /** @var string */
    protected $full;

    public function __construct(Url $url, $file, $full)
    {
        $this->url = $url;
        $this->file = $file;
        $this->full = $full;
    }

    public function addTo(HtmlElement $parent)
    {
        $url = $this->url;
        $file = $this->file;
        $params = $url->getParams();
        $maxPercentile = $params->get('maxPercentile');
        $smoke = $params->get('smoke');

        if ($this->full) {
            $parent->add(Link::create(
                Icon::create('zoom-out'),
                $url->without('file'),
                null,
                [
                    'title' => $this->translate('Zoom out'),
                    'data-js-toggle' => 'height=120',
                    'data-js-toggleOther' => 'height=560',
                    'data-js-toggleOtherContent' => Icon::create('zoom-in')->render(),
                ]
            ));
        } else {
            $parent->add(Link::create(
                Icon::create('zoom-in'),
                $url->with('file', $file),
                null,
                [
                    'title' => $this->translate('Zoom in'),
                    'data-js-toggle' => 'height=560',
                    'data-js-toggleOther' => 'height=120',
                    'data-js-toggleOtherContent' => Icon::create('zoom-out')->render(),
                ]
            ));
        }
        $parent->add($downLink = Link::create(
            Icon::create('download'),
            '',
            null,
            [
                'target' => '_blank',
                'title'  => $this->translate('Download Image File')
            ]
        ));
        if ($smoke) {
            $parent->add(Link::create(
                Icon::create('eye'),
                $url->without('smoke'),
                null,
                [
                    'title' => $this->translate('Remove min/max "smoke"'),
                    'data-js-toggle' => 'smoke=0',
                    'data-js-toggleOther' => 'smoke=1',
                    'data-js-toggleOtherContent' => Icon::create('eye-off')->render(),
                ]
            ));
        } else {
            $parent->add(Link::create(
                Icon::create('eye-off'),
                $url->with('smoke', true),
                null,
                [
                    'title' => $this->translate('Show min/max "smoke"'),
                    'data-js-toggle' => 'smoke=1',
                    'data-js-toggleOther' => 'smoke=0',
                    'data-js-toggleOtherContent' => Icon::create('eye')->render(),
                ]
            ));
        }
        if ($maxPercentile) {
            // Usually smoke only... but ... JS
            $parent->add(Link::create(
                '100%',
                $url->without('maxPercentile'),
                null,
                [
                    'title' => $this->translate('Show MAX value peaks'),
                    'data-js-toggle' => 'maxPercentile=100',
                    'data-js-toggleOther' => 'maxPercentile=95',
                    'data-js-toggleOtherContent' => '95%',
                ]
            ));
        } else {
            $parent->add(Link::create(
                '95%',
                $url->with('maxPercentile', 95),
                null,
                [
                    'title' => $this->translate('Show only 95 percentiles of MAX values'),
                    'data-js-toggle' => 'maxPercentile=95',
                    'data-js-toggleOther' => 'maxPercentile=100',
                    'data-js-toggleOtherContent' => '100%',
                ]
            ));
        }
    }
}
