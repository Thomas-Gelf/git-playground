<?php

namespace Icinga\Module\Metrics\Web\Widget;

use gipfl\IcingaWeb2\Link;
use gipfl\IcingaWeb2\Url;
use gipfl\Translation\TranslationHelper;
use Icinga\Module\Metrics\ExtendedRrdInfo;
use ipl\Web\Widget\ActionBar;

class ImageActions extends ActionBar
{
    use TranslationHelper;

    protected RrdImg $image;
    protected Url $url;
    protected ExtendedRrdInfo $fileInfo;

    protected $defaultAttributes = [
        'class' => 'gipfl-action-bar',
    ];

    public function __construct(RrdImg $image, ExtendedRrdInfo $fileInfo, Url $url)
    {
        parent::__construct();
        $this->image = $image;
        $this->url = $url;
        $this->fileInfo = $fileInfo;
    }

    protected function assemble()
    {
        $img = $this->image;
        $baseUrl = $img->getUrl();
        if ($baseUrl->getPath() !== 'metrics/big/img') {
            $this->add(
                Link::create($this->translate('Zoom'), $baseUrl->with([
                    'referrerUrl' => $this->url->getPath(),
                    'referrerQueryString' => $this->url->getQueryString(),
                ])->setPath('metrics/big/img'), [
                    'uuid' => $this->fileInfo->getUuid()->toString()
                ], [
                    'class' => 'icon-zoom-in',
                ]),
            );
        }
        $this->add([
            Link::create($this->translate('Add to basket'), $baseUrl->with([
                'referrerUrl' => $this->url->getPath(),
                'referrerQueryString' => $this->url->getQueryString(),
            ])->setPath('metrics/basket/add'), null, [
                'class' => 'icon-tag',
            ]),
            Link::create($this->translate('SVG'), $baseUrl->with([
                'download' => true,
                'format'   => 'svg'
            ]), null, [
                'class' => 'icon-download',
                'target' => '_blank'
            ]),
            Link::create($this->translate('PNG'), $baseUrl->with([
                'download' => true,
                'format' => 'png'
            ]), null, [
                'class' => 'icon-download',
                'target' => '_blank'
            ]),
            Link::create($this->translate('Inspect'), $baseUrl->with([
                'showCommand' => true,
            ]), null, [
                'class' => 'icon-bug',
            ]),
        ]);
    }
}
