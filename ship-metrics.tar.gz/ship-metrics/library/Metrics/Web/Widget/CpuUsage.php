<?php

namespace Icinga\Module\Metrics\Web\Widget;

use gipfl\Translation\TranslationHelper;
use Icinga\Module\Metrics\ExtendedRrdInfo;
use Icinga\Module\Metrics\Template\Cpu;
use ipl\Html\Html;

class CpuUsage extends BunchOfImages
{
    use TranslationHelper;

    protected string $layout;
    protected ?int $max = null;
    protected array $files;

    public function __construct(array $files, $layout)
    {
        $this->layout = $layout;
        $this->files = $files;
    }

    public function setMax(?int $max): CpuUsage
    {
        $this->max = $max;

        return $this;
    }

    protected function assemble()
    {
        $this->addTitle($this->translate('Metrics Node CPU Usage'), 'gauge');
        $this->add(new RrdLegend(new Cpu()));
        $div = Html::tag('div', [
            // 'style' => 'background-image: linear-gradient(to bottom right, #888888, #494949); color: white;
            // height: 20em;',
        ], [
            Html::tag('div', '11th Gen Intel(R) Core(TM) i7-1185G7 @ 3.00GHz')
        ]);
        $this->add($div);
        $cnt = 0;
        foreach ($this->files as $file) {
            $div->add(Html::tag('div', ['style' => 'text-align: right'], 'CPU ' . $cnt));
            $cnt++;
            $div->add($this->makeCpu($file));
        }
    }

    protected function makeCpu(ExtendedRrdInfo $info)
    {
        $layout = $this->layout;
        // $layout = 'size3';
        switch ($layout) {
            case 'size1':
                $height = $width = '160';
                $height = $width = '105';
                break;
            case 'size2':
                $height = $width = '320';
                break;
            case 'size4':
                $height = '320';
                $width = '650';
                break;
            case 'size5':
                $height = '160';
                $height = '320';
                $width = '650';
                break;
            case 'size3':
                $height = '160';
                $height = '100';
                $width = '410';
                $width = '410';
                break;
            default:
                $height = '160';
                $width = '1300';
                break;
        }
        $this->getAttributes()->add('class', $layout);
        $img = new RrdImg($info->getFilename(), 'cpu', $width, $height, [
            // 'onlyGraph' => true,
            // 'onlyWhite' => true,
            // 'max' => 25, //$this->max,
            'max' => $this->max,
            'disableDatasources' => 'Idle' // TODO: 'Idle' is WRONG, it's 'idle'
            // 'disableDatasources' => 'idle'
        ]);
        $img = $this->linkToFile($info, $img);

        return $img;
    }
}
