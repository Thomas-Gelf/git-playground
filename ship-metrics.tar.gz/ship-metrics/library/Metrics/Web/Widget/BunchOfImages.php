<?php

namespace Icinga\Module\Metrics\Web\Widget;

use gipfl\IcingaWeb2\Link;
use Icinga\Module\Metrics\ExtendedRrdInfo;
use ipl\Html\BaseHtmlElement;
use ipl\Html\Html;

abstract class BunchOfImages extends BaseHtmlElement
{
    protected $tag = 'div';

    protected $defaultAttributes = [
        'style' => 'width: 36em; display: inline-block; vertical-align: top;',
        'class' => 'rrd-img-set',
    ];

    protected function addTitle($title, $icon)
    {
        $this->add(Html::tag('h1', ['class' => "icon-$icon"], ' ' . $title)); // TODO: no space
    }

    protected function linkToFile(ExtendedRrdInfo $info, $label): Link
    {
        return Link::create($label, 'metrics/rra/file', [
            'uuid' => $info->getUuid()->toString()
        ], [
            'data-base-target' => '_next',
            'style' => 'display: inline-block',
        ]);
    }
}
