<?php

namespace Icinga\Module\Metrics\Web\Widget;

use Icinga\Module\Metrics\Template\RrdTemplate;
use ipl\Html\BaseHtmlElement;
use ipl\Html\Html;

class RrdLegend extends BaseHtmlElement
{
    protected $tag = 'div';

    protected $defaultAttributes = [
        'class' => 'legend-health'
    ];

    protected RrdTemplate $template;

    public function __construct(RrdTemplate $template)
    {
        $this->template = $template;
    }

    protected function assemble()
    {
        $parts = $this->template->legend;
        if (count($parts) > 3) {
            $width = '6.5em';
        } else {
            $width = '10.5em';
        }
        foreach (array_reverse($parts) as $name => $color) {
            $this->add(Html::tag('div', [
                'style' => 'display: inline-block; width: ' . $width
            ], [
                $this->colorLegend($color),
                ' ',
                Html::tag('a', [
                    'href'         => '#',
                    'class'        => 'rrd-toggle-ds',
                    'data-ds-name' => $name
                ], $name),
            ]));
        }
    }

    protected function colorLegend($color)
    {
        return Html::tag('div', [
            'style' => "border: 1px solid rgba(0, 0, 0, 0.3); background-color: $color;"
                . ' width: 0.8em; height: 0.8em; margin: 0.1em; display: inline-block; vertical-align: middle;'
        ]);
    }
}
