<?php

namespace Icinga\Module\Metrics\Web\Widget;

use Clue\React\Block;
use gipfl\Translation\TranslationHelper;
use gipfl\IcingaWeb2\Link;
use gipfl\IcingaWeb2\Url;
use Icinga\Module\Metrics\Daemon\RemoteClient;
use Icinga\Web\Notification;
use ipl\Html\HtmlDocument;
use React\EventLoop\LoopInterface;

class FileActions extends HtmlDocument
{
    use TranslationHelper;

    /** @var Url */
    protected $url;

    /** @var string */
    protected $filename;

    public function __construct(Url $url, $filename)
    {
        $this->url = $url;
        $this->filename = $filename;
    }

    protected function assemble()
    {
        $this->add($this->createFileActions());
    }

    protected function createFileActions()
    {
        return [
            Link::create(
                $this->translate('Flush'),
                $this->url->with('flush', true),
                null,
                ['class' => 'icon-reschedule']
            ),
            Link::create(
                $this->translate('Forget'),
                $this->url->with('forget', true),
                null,
                ['class' => 'icon-trash']
            ),
            Link::create(
                $this->translate('Flush and Forget'),
                $this->url->with('flushandforget', true),
                null,
                ['class' => 'icon-spinner']
            ),
            Link::create(
                $this->translate('Delete'),
                $this->url->with('delete', true),
                null,
                ['class' => 'icon-cancel']
            ),
        ];
    }

    /**
     * @param RemoteClient $client
     * @param $filename
     * @return bool|Url|\Icinga\Web\Url
     */
    public function eventuallyRun(RemoteClient $client, LoopInterface $loop)
    {
        $filename = $this->filename;
        $params = $this->url->getParams();
        if ($params->get('flush')) {
            if ($this->runAction($client, $loop, 'flush')) {
                Notification::success("'$filename' has been flushed");
                return $this->url->without('flush');
            } else {
                Notification::error("Unable to flush '$filename'");
            }
        }
        if ($params->get('forget')) {
            if ($this->runAction($client, $loop, 'forget')) {
                Notification::success(
                    "'$filename' has been forgotten (removed from Cache). Data might have been lost."
                );
                return Url::fromPath('metrics/rra/forgotten', [
                    'filename' => $filename
                ]);
            } else {
                Notification::error("Unable to forget '$filename'");
            }
        }
        if ($params->get('flushandforget')) {
            if ($this->runAction($client, $loop, 'flushAndForget')) {
                Notification::success("'$filename' has been flushed and removed from cache");
                return Url::fromPath('metrics/rra/forgotten', [
                    'filename' => $filename
                ]);
            } else {
                Notification::error("Unable to flush and forget '$filename'");
            }
        }
        if ($params->get('delete')) {
            if ($this->runAction($client, $loop, 'delete')) {
                Notification::success("'$filename' has been deleted");
                return Url::fromPath('metrics/rra/deleted', [
                    'filename' => $filename
                ]);
            } else {
                Notification::error("Unable to delete '$filename'");
            }
        }

        return false;
    }

    protected function runAction(RemoteClient $client, LoopInterface $loop, $method)
    {
        $file = $this->filename;
        $promise = $client->request('rrd.' . $method, ['file' => $file]);

        return Block\await($promise, $loop, 3);
    }
}
