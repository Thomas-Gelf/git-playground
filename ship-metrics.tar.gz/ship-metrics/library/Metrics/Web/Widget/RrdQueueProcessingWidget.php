<?php

namespace Icinga\Module\Metrics\Web\Widget;

use Icinga\Module\Metrics\ExtendedRrdInfo;
use ipl\Html\Html;
use Icinga\Module\Metrics\Template\RrdQueueProcessing;

class RrdQueueProcessingWidget extends BunchOfImages
{
    protected ExtendedRrdInfo $info;

    public function __construct(ExtendedRrdInfo $info)
    {
        $this->info = $info;
    }

    protected function assemble()
    {
        $this->addTitle('RRD Queue Processing (Lines, per second)', 'chart-line');
        $this->add(new RrdLegend(new RrdQueueProcessing()));
        $this->add(Html::tag('div', [
            'style' => 'width: 18em; display: inline-block;'
        ], [
            $this->linkToFile(
                $this->info,
                new RrdImg($this->info->getFilename(), 'RRDHealth', 440, 180)
            )
        ]));
    }
}
