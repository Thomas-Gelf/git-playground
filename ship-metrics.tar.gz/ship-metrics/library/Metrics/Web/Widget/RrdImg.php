<?php

namespace Icinga\Module\Metrics\Web\Widget;

use gipfl\IcingaWeb2\Url;
use gipfl\Json\JsonString;
use Icinga\Module\Metrics\Daemon\RemoteClient;
use Icinga\Web\UrlParams;
use ipl\Html\BaseHtmlElement;
use ipl\Html\Html;
use ipl\Html\HtmlElement;
use React\EventLoop\LoopInterface;
use stdClass;
use function Clue\React\Block\await;

class RrdImg extends BaseHtmlElement
{
    const TRANSPARENT_GIF = 'data:image/gif;base64,R0lGODlhAQABAJAAAAAAAAAAACH5BAEUAAAALAAAAAABAAEAAAICRAEAOw==';

    protected $tag = 'div';
    protected $defaultAttributes = [
        'class' => 'rrd-graph'
    ];

    protected string $rrdImgUrl = 'metrics/img';
    protected string $file;
    protected string $template;
    protected int $width;
    protected int $height;
    protected array $extraParams;
    protected ?HtmlElement $imgTag = null;
    protected bool $loadImmediately = false;
    /** @var \stdClass|bool|null */
    protected $loaded = null;
    protected ?RemoteClient $remoteClient = null;
    protected ?LoopInterface $loop = null;
    protected ?Url $url = null;

    public function __construct(string $file, string $template, int $width, int $height, array $extraParams = [])
    {
        $this->file = $file;
        $this->template = $template;
        $this->width = $width;
        $this->height = $height;
        $this->extraParams = $extraParams;
    }

    public static function fromUrlParams(array $params)
    {
        $extraParams = $params;
        foreach (['file', 'template', 'width', 'height'] as $key) {
            unset($extraParams[$key]);
        }

        return new static(
            $params['file'] ?? null,
            $params['template'] ?? 'default',
            $params['width'] ?? 640,
            $params['height'] ?? 280,
            $extraParams
        );
    }

    public function getImg(): HtmlElement
    {
        if ($this->imgTag === null) {
            $this->imgTag = $this->prepareImgTag();
        }

        return $this->imgTag;
    }

    public function getUrl(): Url
    {
        if ($this->url === null) {
            $this->url = $this->prepareUrl();
        }

        return $this->url;
    }

    /**
     * @return bool|stdClass|null
     */
    public function getLoaded()
    {
        if ($this->loaded === null) {
            $this->getImg(); // triggers loading
        }

        return $this->loaded;
    }

    protected function prepareUrl(): Url
    {
        $end = floor(time() / 60) * 60;
        $start = $end - 28800 * 4;

        $extraParams = $this->extraParams;
        if (isset($extraParams['end'])) {
            $end = $extraParams['end'];
            unset($extraParams['end']);
        }
        if (isset($extraParams['start'])) {
            $start = $extraParams['start'];
            unset($extraParams['start']);
        }

        $params = [
                'file'     => $this->file,
                'height'   => $this->height,
                'width'    => $this->width,
                // 'format'   => 'png',
                'start'    => $start,
                'end'      => $end,
                'template' => $this->template,
            ] + $extraParams;

        return Url::fromPath($this->rrdImgUrl, $params);
    }

    protected function prepareImgTag(): HtmlElement
    {
        $img = Html::tag('img');
        $url = $this->getUrl();

        $attrs = [
            'border' => '0',
            // TODO: we want back to 100% width/height. It's tricky, as it collides with "load immediately, once it goes
            // to manual time selection in the Browser
            'height' => $this->height,
            'width'  => $this->width,
            'style'  => \sprintf(
                "height: %spx; width: %spx; border: none;",
                $this->height,
                $this->width
            ),
            'alt'   => '',
            'class' => 'rr-img',
            'data-rrd-url' => $url,
        ];
        $this->tryToLoad($url->getParams());
        if ($this->loaded) {
            $this->appendLoadedAttrs($attrs, $this->loaded);
        } else {
            $attrs['src'] = self::TRANSPARENT_GIF;
        }
        $img->addAttributes($attrs);
        return $img;
    }

    protected function appendLoadedAttrs(array &$attrs, object $loaded)
    {
        $attrs['data-graph'] = JsonString::encode($loaded->graph);
        $attrs['data-image'] = JsonString::encode($loaded->image);
        $attrs['data-title'] = isset($loaded->title) ? JsonString::encode($loaded->title) : null;
        $attrs['data-value'] = JsonString::encode($loaded->value);
        $attrs['src'] = $loaded->raw;
        $attrs['data-loaded'] = '1';
    }

    protected function assemble()
    {
        $this->add($this->getImg());
    }

    protected function tryToLoad(UrlParams $params)
    {
        if (! $this->loadImmediately) {
            $this->loaded = false;
            return;
        }
        // TODO: Catch, error image. Really? Probably not for timeouts
        try {
            $img = ImgRenderer::fromUrlParams($params);
            $result = await($this->remoteClient->request('rrd.graph', [
                'command' => $img->getCommandString(),
                'format'  => \strtoupper($params->get('format', 'svg')),
            ]), $this->loop, 0.6);
            $result->print = (object) $img->getLastGraph()->translatePrintLabels($result->print);

            $this->loaded = $result;
        } catch (\Exception $e) {
        }
    }

    public function loadImmediately(RemoteClient $client, LoopInterface $loop, $load = true)
    {
        $this->loadImmediately = $load;
        $this->remoteClient = $client;
        $this->loop = $loop;
    }
}
