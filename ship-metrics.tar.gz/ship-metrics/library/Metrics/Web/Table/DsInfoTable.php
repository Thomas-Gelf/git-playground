<?php

namespace Icinga\Module\Metrics\Web\Table;

use gipfl\IcingaWeb2\Link;
use gipfl\RrdTool\RrdInfo;
use gipfl\Translation\TranslationHelper;
use Icinga\Date\DateFormatter;
use Icinga\Module\Metrics\Web\RrdFormat;
use Icinga\Module\Metrics\Web\Widget\RrdImg;
use ipl\Html\Table;

class DsInfoTable extends Table
{
    use TranslationHelper;

    protected $defaultAttributes = [
        'class' => 'common-table'
    ];

    protected $info;
    protected $summary;
    protected $oldest;
    protected $last;

    public function __construct(RrdInfo $info, $summary, $oldest, $last)
    {
        $this->info = $info;
        $this->summary = $summary;
        $this->oldest = $oldest;
        $this->last = $last;
    }

    protected function assemble()
    {
        $info = $this->info;
        $summary = $this->summary;
        $filename = $info->getFilename();
        $headers = [$this->translate('Preview')];
        if ($this->summary) {
            $headers[] = $this->translate('MIN / AVG / MAX / STDEV');
        }
        $this->getHeader()->add(Table::row(array_merge($headers, [
            $this->translate('Name'),
            $this->translate('Type'),
            $this->translate('Heartbeat (min)'),
            $this->translate('Limited MIN / MAX'),
        ]), null, 'th'));
        foreach ($info->getDsList()->getDataSources() as $dsInfo) {
            $dsName = $dsInfo->getName();
            if (isset($summary->$filename->$dsName)) {
                $fSummary = $summary->$filename->$dsName;
            } else {
                $fSummary = null;
            }
            $now = \time();
            $columns = [
                [
                    // $this->createDsImage($filename, $dsName, $this->oldest, $this->last, 120, 20),
                    // ' ',
                    $this->createDsImage($filename, $dsName, $now - 4 * 3600, $now, 240, 20),
                ],
            ];
            if ($this->summary) {
                $columns[] = $fSummary ? \sprintf(
                    '%s / %s / %s / %s',
                    RrdFormat::number($fSummary->min_value),
                    RrdFormat::number($fSummary->avg_value),
                    RrdFormat::number($fSummary->max_value),
                    RrdFormat::number($fSummary->stdev_value)
                ) : '- unavailable -';
            }
            $this->add(Table::row(array_merge($columns, [
                Link::create($dsName, 'metrics/graph', [
                    'file' => $filename,
                    'ds'  => $dsName
                ]),
                $dsInfo->getType(),
                $dsInfo->getHeartbeat(),
                \sprintf(
                    '%s / %s',
                    $dsInfo->hasMin() ? $dsInfo->getMin() : '-',
                    $dsInfo->hasMax() ? $dsInfo->getMax() : '-'
                ),
                // last_ds, value, unknown_sec
            ])));
        }
    }

    protected function createDsImage($filename, $dsName, $from, $to, $width, $height): RrdImg
    {
        return (new RrdImg($filename, 'default', $width, $height, [
            'rra' => 'AVERAGE',
            'ds' => $dsName,
            'onlyGraph' => true,
            'start' => $from,
            'end' => $to,
            'disableCached' => true,
        ]))->addAttributes([
            'style' => sprintf(
                'border-left: 1px solid #ccc; border-bottom: 1px solid #ccc; padding: 0; width: %spx; height: %spx',
                $width,
                $height
            ),
            'title' => sprintf(
                '%s - %s',
                DateFormatter::formatDateTime($from),
                DateFormatter::formatDateTime($to)
            ),
            'width' => 120,
        ]);
    }
}
