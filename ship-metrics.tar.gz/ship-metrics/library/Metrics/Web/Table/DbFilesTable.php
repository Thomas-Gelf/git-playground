<?php

namespace Icinga\Module\Metrics\Web\Table;

use gipfl\IcingaWeb2\Link;
use gipfl\IcingaWeb2\Table\ZfQueryBasedTable;
use Ramsey\Uuid\Uuid;

class DbFilesTable extends ZfQueryBasedTable
{
    protected $searchColumns = [
        'ci.hostname',
        'ci.subject',
        'ci.instance',
        'f.filename',
    ];

    protected function renderRow($row): array
    {
        return [
            $row->hostname ?? '-',
            $row->subject ?? '-',
            $this->linkInstanceToFile($row)
        ];
    }

    protected function linkInstanceToFile($row): Link
    {
        return Link::create(
            $row->instance ?? '-',
            'metrics/rra/graph',
            ['uuid' => Uuid::fromBytes($row->uuid)->toString()]
        );
    }

    protected function prepareQuery()
    {
        return $this->db()->select()->from('ci', [
            'ci_uuid'   => 'ci.uuid',
            'file_uuid' => 'f.uuid',
            'ci.hostname',
            'ci.subject',
            'ci.instance',
            'f.filename',
            'f.deleted',
        ])->join(['f' => 'rrd_file'], 'f.ci_uuid = ci.uuid')
            ->order('ci.hostname')
            ->order('ci.subject')
            ->order('ci.instance');
    }
}
