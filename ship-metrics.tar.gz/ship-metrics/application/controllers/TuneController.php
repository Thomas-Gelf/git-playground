<?php

namespace Icinga\Module\Metrics\Controllers;

class TuneController extends ControllerBase
{
    /**
     * @throws \Icinga\Exception\MissingParameterException
     */
    public function tuneAction()
    {
        $filename = $this->params->getRequired('file');
        $result = $this->syncRpcCall('rrd.tune', [
            'file' => $filename,
            'tuning'  => "--maximum iowait:100 --maximum idle:100"
        ]);
        var_dump($result);
        exit;
    }

    /**
     * @throws \Icinga\Exception\MissingParameterException
     */
    public function recreateAction()
    {
        $filename = $this->params->getRequired('file');
        $result = $this->syncRpcCall('rrd.recreate', [
            'filename' => $filename,
        ]);
        var_dump($result);
        exit;
    }
}
