<?php

$section = $this->menuSection(N_('Metrics'))->setIcon('chart-area')->setUrl('metrics/health')->setPriority(40);
$section->add(N_('Basket'))
    ->setUrl('metrics/basket')
    ->setPriority(20);
$section->add(N_('Metric Inventory'))
    ->setUrl('metrics/files')
    ->setPriority(30);
