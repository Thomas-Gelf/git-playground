<?php

$this->provideJsFile('rrd.js');
$this->provideHook('grapher');
