-- moved away, was part of RrdCacheD
local function splitKeyValue(pair)
    local pos, key, val
    pos = string.find(pair, '=')
    if pos == nil then
        return nil
    end

    key = string.sub(pair, 0, pos - 1)
    -- remove trailing Plugin perfdata UOM
    val = string.sub(pair, pos + 1)
    -- TODO: calculate KMT
    val = string.gsub(val, '[KMGT]B$', '')
    val = string.gsub(val, '[Bs%%c]$', '')

    return {key, val}
end

local function parseInfluxValuePairs(line, ci)
    local ds_names = ci.ds_names;
    local nameIdx = table.flipArray(ds_names)
    local dsMap = ci.dsMap;
    local currentKey
    local keyVal
    local pairs = {}
    local segments = string.split(line, ',')

    for _, keyValString in ipairs(segments) do
        keyVal = splitKeyValue(keyValString)

        -- No key=val, invalid line
        if keyVal == nil then
            return nil
        end

        -- ds_name not known, defer this line
        if nameIdx[keyVal[1]] == nil then
            return nil
        end

        currentKey = keyVal[1]
        if dsMap == nil then
            -- nix? defer, to rewrite CI-Config?
        else
            currentKey = TableHelper.mapKey(currentKey, dsMap)
        end

        pairs[currentKey] = keyVal[2]
    end

    return pairs
end
