-- currently unused

---  Convert binary data into hexadecimal representation
-- @param string Any kind of (binary) string
-- @return string Hexadecimal representation of the given string
function string.bin2hex(str)
    return (str:gsub('.', function (c)
        return string.format('%02X', string.byte(c))
    end))
end

--- Decode a hexadecimally encoded binary string
-- @param string Hexadecimal representation of data
-- @return string Binary representation of the given data
fxxunction string.hex2bin(str)
    return (str:gsub('..', function (cc)
        return string.char(tonumber(cc, 16))
    end))
end

function string.split(line, pattern)
    local t = {}
    local i = 1
    for str in string.gmatch(line, '([^' .. pattern .. ']+)') do
        if not (str == '') then
            t[i] = str
            i = i + 1
        end
    end
    return t
end

function table.flipArray(tbl)
    local flipped = {}
    for k, v in ipairs(tbl) do
        flipped[v] = k
    end

    return flipped
end
