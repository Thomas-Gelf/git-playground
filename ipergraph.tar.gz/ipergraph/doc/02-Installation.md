apt -y install redis-server && systemctl disable --now redis-server.service

