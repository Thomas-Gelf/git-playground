(function(window, $) {
    'use strict';

    /**
     * Theory of operation
     * ===================
     *
     * .rrd-graph
     * .rrd-selection
     * .rrd-image
     * .rrd-controls
     * .rrd-cursor
     */

    /**
     * We create a container instance for every Icinga Web 2
     *
     * Only task: notify about changed width
     *
     * @param $container
     * @constructor
     */
    const RrdLayoutContainer = function ($container) {
        this.$container = $container;
        this.width = null;
    };

    RrdLayoutContainer.prototype = {
        checkForChangedWidth: function (handler) {
            var $col = this.$container;
            var width = null;

            if ($col.css('display') !== 'none') {
                width = $col.width();
            }

            if (this.width !== width) {
                this.width = width;
                handler($col, width);
            }
        },
    };

    /**
     * RrdLayout is responsible for
     * @constructor
     */
    const RrdLayout = function () {
        this.containers = [];
        this.callbacks = [];
        this.callbackHandler = null;
        this.initialize();
    };

    RrdLayout.prototype = {
        initialize: function () {
            console.log('Main RRD');
            let _this = this;
            this.callbackHandler = this.notifyChange.bind(this);
            // TODO: dynamic container detection
            this.initializeContainer($('#col1'));
            this.initializeContainer($('#col2'));
            $(window).on('resize', this.checkForChangedWidth.bind(_this));
            this.checkForChangedWidth();
        },

        initializeContainer: function ($container) {
            this.containers.push(new RrdLayoutContainer($container));
        },

        checkForChangedWidth: function () {
            var handler = this.callbackHandler;
            $.each(this.containers, function (idx, container) {
                container.checkForChangedWidth(handler);
            });
        },

        onChangedWidth: function (callback) {
            this.callbacks.push(callback);
        },

        notifyChange: function ($container, width) {
            $.each(this.callbacks, function (idx, callback) {
                callback($container, width);
            });
        }
    };

    const RrdCursor = function () {
        this.timestamp = null;
        this.visible = false;
    };

    RrdCursor.prototype = {
        isVisible: function () {
            return this.visible;
        },

        isHidden: function () {
            return ! this.visible;
        },

        show: function (timestamp) {
            if (typeof timestamp !== 'undefined') {
                this.timestamp = timestamp;
            }
            this.visible = true;
        },

        hide: function () {
            this.visible = false;
        },

        getTimestamp: function () {
            return this.timestamp;
        }
    };

    const RrdGraph = function ($element) {
        this.$element = $element;
        this.$cursor = null;
        this.id = $element.attr('id');
        this.top = null;
        this.left = null;
        this.width = null;
        this.height = null;
        this.start = null;
        this.end = null;
        this.expectedStart = null;
        this.expectedEnd = null;
        this.imageWidth = null;
        this.imageHeight = null;
        this.currentTimeStamp = null;
        this.selection = false;

        this.initialize();
    };

    RrdGraph.prototype = {
        initialize: function () {
            this.$element.data('graph', this.$element.find('.rr-img').data('graph'));
            this.$element.data('image', this.$element.find('.rr-img').data('image'));
            this.refreshFromData();
        },

        isSelecting: function () {
            return this.selection !== false;
        },

        getSelection: function () {
            if (this.selection === false) {
                this.$element.addClass('selecting');
                this.selection = new RrdImageSelection(this);
            }

            return this.selection;
        },

        clearSelection: function () {
            if (this.isSelecting()) {
                this.$element.removeClass('selecting');
                this.selection.remove();
                this.selection = false;
            }
        },

        hasImage: function () {
            return this.top !== null;
        },

        refreshFromData: function () {
            const graphData = this.$element.data('graph');
            const imgData = this.$element.data('image');
            if (typeof graphData === 'undefined') {
                // console.log('Graph has no data', this.$element);
                return;
            }
            this.top = graphData.top;
            this.left = graphData.left;
            this.width = graphData.width;
            this.height = graphData.height;
            this.start = graphData.start;
            this.end = graphData.end;
            this.imageWidth = imgData.width;
            this.imageHeight = imgData.height;
            this.$element.css({
                // This is currently required to limit our selection range
                // height: imgData.height + 'px',
                width: imgData.width + 'px'
            });
            this.clearSelection();
            this.refreshDebug();
        },

        getId: function () {
            return this.id;
        },

        getUrl: function () {
            return this.getImgElement().data('rrdUrl');
        },

        getElement: function () {
            return this.$element;
        },

        getImgElement: function () {
            // TODO: cache this
            return this.$element.find('.rr-img');
        },

        refreshDebug: function () {
            this.debug(' t=' + this.top + ' l=' + this.left + ' w=' + this.width + ' h=' + this.height);
        },

        debug: function (text) {
            if (this.getHeight() < 40) {
                return;
            }
            let d = new Date(this.getCurrentTimestamp() * 1000);
            let l = new Date(this.getStart() * 1000);
            let r = new Date(this.getEnd() * 1000);
            this.$element.find('.rrd-debug').html(l.toLocaleString() + ' - ' + r.toLocaleString() + '(' + d.toLocaleString() + '): ' + text).show();
        },

        stillExists: function () {
            return this.$element.parents('html').length > 0;
        },

        getTimeForMouseEvent: function (event) {
            var x = event.clientX - this.$element.offset().left;
            return this.calculateTimeFromOffset(x);
        },

        calculateTimeFromOffset: function (offset) {
            return this.getStart() + ((offset - this.getLeft()) / this.getWidth() * this.getDuration());
        },

        getHorizontalOffsetForMouseEvent: function (event) {
            return event.clientX - this.$element.offset().left;
        },

        getTimeOffset: function (timestamp) {
            return parseInt(this.getLeft() + ((timestamp - this.getStart()) / this.getDuration()) * this.getWidth());
        },

        refreshCursor: function (cursor) {
            if (cursor.isHidden()) {
                this.hideCursor();
            } else if (this.showsTimestamp(cursor.getTimestamp())) {
                this.showCursor(cursor.getTimestamp());
                this.refreshDebug();
            } else {
                if (cursor.getTimestamp() < this.getStart()) {
                    this.showCursor(this.getStart());
                } else {
                    this.showCursor(this.getEnd());
                }
            }
        },

        showCursor: function (timestamp) {
            if (timestamp && this.showsTimestamp(timestamp)) {
                if (this.$cursor === null) {
                    this.$cursor = $('<div class="rrd-cursor"></div>');
                    this.$element.append(this.$cursor);
                }
                let x = this.getTimeOffset(timestamp);
                this.$cursor.css({
                    left: x + 'px',
                    top: this.getTop() + 'px',
                    height: this.getHeight() + 'px'
                });
                this.currentTimeStamp = Math.round(timestamp);

                this.$cursor.show();
            } else {
                this.hideCursor();
            }
        },

        hideCursor: function () {
            if (this.$cursor !== null) {
                this.$cursor.hide();
            }
        },

        showsTimestamp: function (ts) {
            return ts >= this.start && ts <= this.end;
        },

        getDuration: function () {
            return this.getEnd() - this.getStart();
        },

        getTop: function () {
            return this.top;
        },

        getLeft: function () {
            return this.left;
        },

        getWidth: function () {
            return this.width;
        },

        getHeight: function () {
            if (typeof(this.height) === 'undefined') {
                return null;
            }
            return this.height;
        },

        getStart: function () {
            return this.start;
        },

        getEnd: function () {
            return this.end;
        },

        getExpectedStart: function () {
            return this.expectedStart || this.start;
        },

        getExpectedEnd: function () {
            return this.expectedEnd || this.end;
        },

        setExpectedStart: function (start) {
            this.expectedStart = start;
        },

        setExpectedEnd: function (end) {
            this.expectedEnd = end;
        },

        getCurrentTimestamp: function () {
            if (this.currentTimeStamp) {
                return this.currentTimeStamp;
            }

            return Math.round(this.getEnd() - this.getDuration() / 2);
        },

        normalizeFloorWithStep: function (time, step) {
            return Math.floor(time / step) * step;
        },

        normalizeCeilWithStep: function (time, step) {
            return Math.ceil(time / step) * step;
        },

        normalizeRoundWithStep: function (time, step) {
            return Math.round(time / step) * step;
        },

        getStepSizeForDuration: function (duration)
        {
            if (duration < 60 * 70) {
                return 60;
            } else if (duration < 3600 * 25) {
                return 60 * 15;
            } else if (duration < 86400 * 32) {
                return 3600 * 3;
            } else {
                return 86400;
            }
        },

        setDataFromResult: function (requestedUrl, result) {
            const $graph = this.$element;
            const $img = this.getImgElement();
            const graph = result['graph'];
            const image = result['image'];
            const title = result['title'];
            if (typeof title !== 'undefined') {
                $graph.children('p.description').html(title);
            }
            if (typeof graph === 'undefined') {
                return;
            }
            $graph.data('graph', graph);
            $graph.data('image', image);
            $graph.data('value', result['value']);
            $img.attr('src', result['raw']);
            if (image.height > 0) {
                $img.css({height: image.height + 'px'});
            }
            $img.data('rrdUrl', requestedUrl);
            this.refreshFromData();
        }
    };

    const RrdHandler = function (layout) {
        this.layout = layout;
        this.lastId = 0;
        this.graphs = {};
        this.doubleClickTimeout = 300;
        this.clicks = 0;
        this.selectingGraph = false;
        this.selectionRange = null;
        this.skipClick = false;
        this.initialize();
    };

    RrdHandler.prototype = {
        initialize: function () {
            this.cursor = new RrdCursor();
            this.loader = new RrdImageLoader(this);
            document.addEventListener('wheel', function (event) {
                if ($(event.target).closest('.rrd-graph').length > 0) {
                    event.preventDefault();
                }
            }, {passive: false});
            $(document).on('mousemove', '.rrd-graph', this.mouseMove.bind(this));
            $(document).on('mousedown', '.rrd-graph', this.mouseDown.bind(this));
            $(document).on('wheel', '.rrd-graph', this.scroll.bind(this));
            $(document).on('mouseup', this.mouseUp.bind(this));
            $(document).on('click', '.rrd-graph', this.mouseClick.bind(this));
            $(document).on('click', '.rrd-toggle-ds', this.toggleDs.bind(this));
            this.layout.onChangedWidth(this.adjustWidthForAllImages.bind(this));
            $(document).on('rendered', '.container', this.containerRendered.bind(this));
            $(document).on('close-column', '.container', this.containerRendered.bind(this));
            this.registerNewGraphs();
            // this.loadAllGraphs();
            setInterval(this.registerNewGraphs.bind(this), 1000);
        },

        containerRendered: function (event) {
            this.registerNewGraphs();
            // this.loadAllGraphs();
        },

        scroll: function (event) {
            let $container = $(event.currentTarget).closest('div.rrd-img-set');
            let delta = event.originalEvent.deltaY;
            if ($container.length) {
                let _this = this;
                // TODO: Nope. Determine range for active one, and then zoom the other ones
                $.each($container.find('.rrd-graph'), function (idx, $graph) {
                    let graph = _this.getGraphForElement($graph);
                    if (graph) {
                        _this.zoomGraph(graph, delta);
                    }
                })
            } else {
                let graph = this.getGraphForElement(event.currentTarget);
                if (! graph) {
                    icinga.logger.info('Scrolling, no graph');
                    return;
                }

                this.zoomGraph(graph, delta);
            }
            event.stopPropagation();
            event.stopImmediatePropagation();
            return false;
        },

        zoomGraph: function (graph, delta) {
            if (delta === 0 || isNaN(delta)) {
                return;
            }
            if (delta > 0) {
                delta = 3;
            } else {
                delta = -2;
            }
            // +90, -90
            // event.originalEvent.deltaY = 0;
            let maxEnd = Math.floor(new Date().getTime() / 1000);
            let duration = graph.getDuration();
            let position = graph.getCurrentTimestamp();
            if (position === null) {
                return;
            }
            let currentStart = graph.getExpectedStart();
            let currentEnd = graph.getExpectedEnd();
            if (position < currentStart || position > currentEnd) {
                return;
            }
            let stepSize = graph.getStepSizeForDuration(currentEnd - currentStart);
            let left = position - currentStart;
            let right = currentEnd - position;
            let leftFactor = left / duration;
            let rightFactor = right / duration;
            let requestedMod = delta * 900; // TODO: steps
            let newStart = graph.normalizeFloorWithStep(currentStart - requestedMod * leftFactor, stepSize);
            let newEnd = graph.normalizeCeilWithStep(currentEnd + requestedMod * rightFactor, stepSize);

            if (newEnd > maxEnd) {
                newEnd = graph.normalizeCeilWithStep(maxEnd, stepSize);
            }
            if (newStart >= newEnd || isNaN(newStart) || isNaN(newEnd)) {
                return;
            }

            if (newStart === currentStart && newEnd === currentEnd) {
                return;
            }

            this.loader.loadGraph(graph, {
                start: newStart,
                end: newEnd
            });
        },

        mouseClick: function (event) {
            // Left click only
            if (event.which !== 1) {
                return true;
            }
            if (this.skipClick) {
                event.stopPropagation();
                event.preventDefault();
                this.skipClick = false;
                return false;
            } else {
                return true;
            }
        },

        mouseDown: function (event) {
            // Left click only
            if (event.which !== 1) {
                return true;
            }
            return this.startSelecting(event);
        },

        startSelecting: function (event) {
            this.cursor.hide();
            this.refreshCursors();

            var graph = this.getGraphForElement(event.currentTarget);
            if (! graph.hasImage()) {
                return true;
            }
            event.stopPropagation();
            event.preventDefault();
            this.selectingGraph = graph;
            this.selectionRange = new RrdTimeRangeSelection(graph);
            this.updateSelection(event, graph);

            return false;
        },

        updateSelection: function (event, graph)
        {
            var ts = graph.getTimeForMouseEvent(event);
            var range = this.selectionRange;
            if (range) {
                range.setPosition(ts);
                graph.getSelection().adjustSelectionRectangles(
                    graph.getTimeOffset(range.getBegin()) - graph.getLeft(),
                    graph.getTimeOffset(range.getEnd()) - graph.getLeft()
                );
            }
        },

        mouseUp: function (event) {
            if (this.selectingGraph === false || this.selectingGraph === null) { // TODO: why both?
                return true;
            }
            this.clicks++;
            if (this.clicks === 2) {
                this.clicks = 0;
                event.stopPropagation();
                event.preventDefault();
                this.doubleClick(this.selectingGraph);
                return false;
            }
            var _this = this;
            setTimeout(function () {
                _this.clicks = 0;
            }, this.doubleClickTimeout);

            this.endSelecting(event);
            return false;
        },

        isValidSelection: function () {
            return this.selectionRange && this.selectionRange.getBegin() !== this.selectionRange.getEnd();
        },

        endSelecting: function (event) {
            this.cursor.show();
            this.refreshCursors();
            var graph = this.selectingGraph;

            event.stopPropagation();
            event.preventDefault();
            if (this.isValidSelection()) {
                // TODO should be at least 10xStep
                // $('input[name="start"]').val(this.start);
                // $('input[name="end"]').val(this.end);
                this.loader.loadGraph(graph, {
                    start: this.selectionRange.getBegin(),
                    end: this.selectionRange.getEnd()
                });
                this.skipClick = true;
                this.resetSelection();
            } else if (this.selectingGraph) {
                this.resetSelection();
            }
        },

        resetSelection: function () {
            this.selectingGraph.clearSelection();
            this.selectingGraph = null;
            this.selectionRange = null;
        },
/*
        changeSelectionX: function (x) {
            if (x !== this.currentX) {
                var left = Math.min(x, this.startX);
                var right = Math.max(x, this.startX);
                this.currentX = x;
                // console.log('From', left, 'to', right);
                this.adjustSelectionRectangles(left, right);
                this.start = this.calculateTimeFromOffset(left);
                this.end = this.calculateTimeFromOffset(right);
            }
        },
*/
        doubleClick: function (graph) {
            // TODO: combine with dirty/queue
            this.loader.loadGraph(graph, {
                start: false,
                end: false
            });
            this.resetSelection();
        },

        registerNewGraphs: function () {
            let _this = this;
            $('.rrd-graph').not('.rrd-registered').each(function (idx, graph) {
                _this.registerGraph($(graph));
            });
        },

        toggleDs: function (event) {
            var $a = $(event.currentTarget);
            var ds = $a.data('dsName');
            // link -> div -> div. Might be improved
            var _this = this;
            $.each(this.getGraphsRelatedToLegendLink($a), function (idx, graph) {
                var url = graph.getUrl();
                _this.loader.loadGraph(graph, {disableDatasources: _this.toggleDsParam(url, ds)});
            });
        },

        getGraphsRelatedToLegendLink: function ($a) {
            var legendGraphs = [];
            var _this = this;
            $a.parent().parent().parent().find('.rrd-graph').each(function (idx, element) {
                var graph = _this.getGraphForElement(element);
                if (graph) {
                    legendGraphs.push(graph);
                }
            });

            return legendGraphs;
        },

        toggleDsParam: function (url, toggleDs) {
            var params = window.icinga.utils.parseUrl(url).params;
            var disabled = [];
            $.each(params, function (idx, param) {
                if (param.key === 'disableDatasources' && param.value) {
                    disabled = decodeURIComponent(param.value).split(',');
                }
            });
            var dsIdx = disabled.indexOf(toggleDs);
            if (dsIdx > -1) {
                disabled.splice(dsIdx, 1);
            } else {
                disabled.push(toggleDs);
            }

            return disabled.join(',');
        },

        registerGraph: function ($graph) {
            var id = 'rrd-graph_' + ++this.lastId;
            // TODO: check for existing ID
            $graph.attr('id', id);
            $graph.addClass('rrd-registered');
            this.graphs[id] = new RrdGraph($graph);
            if (! $graph.find('img').data('loaded')) {
                this.loader.loadGraph(this.graphs[id], {});
            }

            return this.graphs[id];
        },

        getGraphs: function () {
            return this.graphs;
        },

        getGraphForElement: function (element) {
            let graph = this.graphs[$(element).attr('id')];
            if (typeof graph === 'undefined') {
                return null;
            } else {
                return graph;
            }
        },

        mouseMove: function (event) {
            let graph;

            if (this.selectingGraph) {
                graph = this.selectingGraph;
            } else {
                graph = this.getGraphForElement(event.currentTarget);
            }
            if (! graph) {
                icinga.logger.info('Moving, no graph');
                return;
            }
            if (graph.isSelecting()) {
                this.updateSelection(event, graph);
                return;
            }
            let ts = graph.getTimeForMouseEvent(event);
            if (! isFinite(ts)) {
                // icinga.logger.error('Got no TS on', graph, 'for', event);
                return;
            }
            this.cursor.show(ts);
            this.refreshCursors();
        },

        refreshCursors: function () {
            let cursor = this.cursor;
            $.each(this.graphs, function (idx, foundGraph) {
                foundGraph.refreshCursor(cursor);
            });
        },

        loadAllGraphs: function () {
            let loader = this.loader;
            $.each(this.graphs, function (idx, graph) {
                loader.loadGraph(graph, {});
            });
        },

        adjustWidthForAllImages: function ($container, width) {
            let _this = this;
            width = Math.floor(width);
            width -= 24; // padding, margin
            $container.find('.rrd-graph').each(function (idx, element) {
                let graph = _this.getGraphForElement(element);
                if (! graph) {
                    return;
                }
                let $img = graph.getImgElement();
                if ($img.width() !== width) {
                    // this is for responsiveness:
                    // _this.loader.loadGraph(graph, {width: width});
                    _this.loader.loadGraph(graph, {});// , {width: width});
                }
            });
        }
    };

    /**
     * Takes care of loading images
     *
     * LoadingQueue -> push, load max 6 at once. Once an image is done -> next one. URL changes while not pending: replace
     * Request for a graph with pending request -> deferred queue, add timer with 100ms to deferred timers - if not already set
     *
     * @param rrdHandler
     * @constructor
     */
    const RrdImageLoader = function (rrdHandler) {
        this.rrdHandler = rrdHandler;
        this.deferredRequests = {};
        this.deferredTimers = {};
        this.dirtyGraphs = {};
        this.loadingGraphs = {};
        this.initialize();
    };

    RrdImageLoader.prototype = {
        initialize: function () {
            // TODO: module.icinga.utils
            this.utils = window.icinga.utils;
            setInterval(this.triggerLoading.bind(this), 500);
            this.triggerLoading();
        },

        loadGraph: function (rrdGraph, tweakParams) {
            let url = rrdGraph.getUrl();
            if (typeof url === 'undefined') {
                return;
            }
            url = this.applyUrlParams(url, tweakParams);
            this.tellGraphAboutExpectedParams(rrdGraph, tweakParams);

            let request = $.ajax(url);
            request.done(this.handleGraphResult.bind(this));
            // request.fail(this.onFailure);
            // request.always(this.onComplete);
            request.rrdGraph = rrdGraph;
            request.requestedUrl = url;

            return request;
        },

        tellGraphAboutExpectedParams: function (rrdGraph, expectedParams)
        {
            if (expectedParams.start) {
                rrdGraph.setExpectedStart(expectedParams.start)
            }
            if (expectedParams.end) {
                rrdGraph.setExpectedEnd(expectedParams.end)
            }
        },

        markDirty: function (graph) {
            this.dirtyGraphs[graph.getId()] = graph;
            this.triggerLoading();
        },

        triggerLoading: function () {
            const _this = this;
            $.each(this.dirtyGraphs, function (idx, rrdGraph) {
                let loading = _this.loadingGraphs;
                if (typeof loading[idx] === 'undefined') {
                    loading[idx] = _this.loadGraph(rrdGraph);
                } else {
                    if (! _this.dirtyGraphs[idx].wantsUrl(loading[id].requestedUrl)) {
                        loading[idx].cancel();
                        loading[idx] = _this.loadGraph(rrdGraph);
                    } else {
                    }
                }
            });
        },

        finishLoading: function (rrdGraph, requestedUrl, result) {
            const idx = rrdGraph.getId();
            if (idx in this.dirtyGraphs && this.dirtyGraphs[idx].wantsUrl(requestedUrl)) {
                delete(this.dirtyGraphs[idx]);
            }
            delete(this.loadingGraphs[idx]);
            rrdGraph.setDataFromResult(requestedUrl, result);
            this.addGraphSettingsToContainerUrl(rrdGraph);
        },

        addGraphSettingsToContainerUrl: function (rrdGraph) {
            const $container = rrdGraph.$element.closest('.container');
            const newUrl = this.utils.addUrlParams(this.utils.removeUrlParams($container.data('icingaUrl'), [
                'metricStart',
                'metricEnd'
            ]), {
                metricStart: rrdGraph.getStart(),
                metricEnd: rrdGraph.getEnd(),
            });
            $container.find('>.controls a.refresh-container-control').attr('href', newUrl);
            $container.data({icingaUrl: newUrl});
            icinga.history.pushCurrentState();
        },

        failLoading: function (idx) {
            delete(this.loadingGraphs[idx]);
        },

        handleGraphResult: function (result, textStatus, request) {
            const rrdGraph = request.rrdGraph;
            this.finishLoading(rrdGraph, request.requestedUrl, result);
        },

        applyUrlParams(url, params) {
            params.rnd = new Date().getTime();
            if (params.start === false) {
                url = this.utils.removeUrlParams(url, ['start']);
                delete(params.start);
            }
            if (params.end === false) {
                url = this.utils.removeUrlParams(url, ['end']);
                delete(params.end);
            }
            // Fake end: params.end = Math.floor(new Date().getTime() / 1000);
            url = this.utils.addUrlParams(url, params);

            return url;
        }
    };

    const RrdImageSelection = function (graph) {
        this.graph = graph;
        this.tplSelection = '<div class="rrd-selection"> </div>';
        this.tplBefore = '<div class="rrd-time-not-selection selection-before" style="left: 0"> </div>';
        this.tplMain   = '<div class="rrd-time-selection"> </div>';
        this.tplAfter  = '<div class="rrd-time-not-selection selection-after" style="right: 0"> </div>';
        this.rectBefore = null;
        this.rectMain = null;
        this.rectAfter = null;
        this.initialize();
    };

    RrdImageSelection.prototype = {
        initialize: function () {
            this.rectBefore = $(this.tplBefore);
            this.rectMain = $(this.tplMain);
            this.rectAfter = $(this.tplAfter);
            this.getSelection().append(this.rectAfter, this.rectMain, this.rectBefore);
        },

        getSelection: function() {
            if (typeof(this.$selection) === 'undefined' || this.$selection === null) {
                var $graph = this.graph.getElement();
                var $selection = $graph.find('.rrd-selection');
                if ($selection.length === 0) {
                    $selection = $(this.tplSelection);
                    $graph.prepend($selection);
                    $selection.css({
                        top: this.graph.getTop(),
                        left: this.graph.getLeft(),
                        height: this.graph.getHeight(),
                        width: this.graph.getWidth()
                    });
                }

                this.$selection = $selection;
            }

            return this.$selection;
        },

        isValidSelection: function () {
            // Ask TimeRange?
            return true;
        },

        adjustSelectionRectangles: function (left, right) {
            this.rectBefore.css({
                'width': (left) + 'px'
            });
            this.rectMain.css({
                'left': left + 'px',
                'width': (right - left) + 'px'
            });
            this.rectAfter.css({
                'width': (this.graph.getWidth() - right) + 'px'
            });
            if (this.isValidSelection()) {
                this.rectMain.removeClass('invalid');
            } else {
                this.rectMain.addClass('invalid');
            }
        },

        remove: function () {
            if (this.rectMain !== null) {
                this.rectMain.remove();
                this.rectBefore.remove();
                this.rectAfter.remove();
                this.rectMain = null;
                this.rectBefore = null;
                this.rectAfter = null;
            }
        }
    };

    const RrdTimeRangeSelection = function (graph) {
        this.graph = graph;
        this.start = null;
        this.current = null;
    };

    RrdTimeRangeSelection.prototype = {
        setPosition: function (timestamp) {
            let step = Math.round(this.graph.getDuration() / 100);
            step = this.graph.getStepSizeForDuration(this.graph.getDuration());
            // step = 300;
            if (this.start === null) {
                this.start = this.graph.normalizeRoundWithStep(parseInt(timestamp), step);
            }

            this.current = this.graph.normalizeRoundWithStep(parseInt(timestamp), step);
        },

        getStart: function () {
            return this.start;
        },

        getCurrent: function () {
            return this.current;
        },

        getBegin: function () {
            if (this.current > this.start) {
                return this.start;
            } else {
                return this.current;
            }
        },

        getEnd: function () {
            if (this.current > this.start) {
                return this.current;
            } else {
                return this.start;
            }
        },

        getDuration: function () {
            return this.getEnd() - this.getBegin();
        }
    };

    let startup;
    let w = window;
    function launch() {
        w.rrd = new RrdHandler(new RrdLayout(), w.icinga);
        w.RrdImageSelection = RrdImageSelection;
    }

    function safeLaunch() {
        if (typeof(w.icinga) !== 'undefined' && w.icinga.initialized) {
            clearInterval(startup);
            launch();
            icinga.logger.info('RRD is ready');
        } else {
            console.log('RRD module is still waiting for icinga');
        }
    }

    $(document).ready(function () {
        startup = setInterval(safeLaunch, 150);
        setTimeout(safeLaunch, 1);
    });

})(window, jQuery);
