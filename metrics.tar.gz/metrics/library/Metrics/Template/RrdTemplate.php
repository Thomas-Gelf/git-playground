<?php

namespace Icinga\Module\Metrics\Template;

abstract class RrdTemplate
{
    public $legend = [];
}
