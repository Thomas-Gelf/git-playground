<?php

namespace Icinga\Module\Metrics\Template;

class Cpu extends RrdTemplate
{
    public $legend = [
        'I/O wait'   => '#F96266',
        'Soft IRQ'   => '#F962F5',
        'IRQ'        => '#8362F9',
        'Nice'       => '#D48823',
        'Steal'      => '#000000',
        'Guest'      => '#333333',
        'Guest nice' => '#aaaaaa',
        'System'     => '#F9AF62',
        'User'       => '#F9E962',
        'Idle'       => '#44bb77',
    ];
}
