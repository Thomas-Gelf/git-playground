<?php

namespace Icinga\Module\Metrics\Template;

class RrdCachedOperations extends RrdTemplate
{
    public $legend = [
        'UpdatesReceived' => '#63B4FF',
        'UpdatesWritten'  => '#F96266',
        'DataSetsWritten' => '#30B85D',
    ];
}
