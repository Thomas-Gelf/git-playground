<?php

namespace Icinga\Module\Metrics\Async;

use Exception;
use gipfl\IcingaWeb2\Widget\ControlsAndContent;
use ipl\Html\Error;
use React\EventLoop\Factory;
use React\EventLoop\LoopInterface;
use React\Promise\PromiseInterface;
use function Clue\React\Block\await;
use function Clue\React\Block\awaitAll;

trait Async
{
    /** @var LoopInterface */
    private $loop;

    protected function loop()
    {
        if ($this->loop === null) {
            $this->loop = Factory::create();
        }

        return $this->loop;
    }

    protected function stopLoop()
    {
        if ($this->loop !== null) {
            $this->loop->stop();
        }

        return $this;
    }

    public function waitFor($promises)
    {
        if (! is_array($promises)) {
            $promises = [$promises];
        }
        try {
            awaitAll($promises, $this->loop());
        } catch (Exception $e) {
            $this->showAsyncError($e);

            return false;
        }

        return true;
    }

    public function waitForValues($promises, $allowFailures = false)
    {
        $result = (object) [];
        /** @var PromiseInterface $promise */
        foreach ($promises as $key => $promise) {
            $promise->then(function ($promiseResult) use ($result, $key) {
                $result->$key = $promiseResult;
            }, function (Exception $e) use ($result, $key, $allowFailures) {
                if ($allowFailures) {
                    $result->$key = null;
                } else {
                    throw $e;
                }
            });
        }

        try {
            awaitAll($promises, $this->loop());
        } catch (Exception $e) {
            $this->showAsyncError($e);

            return false;
        }

        return $result;
    }

    /**
     * @param $promise
     * @param bool $allowFailures
     * @return mixed
     */
    public function waitForValue($promise, bool $allowFailures = false)
    {
        $result = null;
        /** @var PromiseInterface $promise */
        $promise->then(function ($promiseResult) use (&$result) {
            $result = $promiseResult;
        }, function (Exception $e) use ($allowFailures) {
            if (! $allowFailures) {
                throw $e;
            }
        });

        try {
            await($promise, $this->loop());
        } catch (Exception $e) {
            $this->showAsyncError($e);
            // No, really?
            return false;
        }

        return $result;
    }

    protected function showAsyncError(Exception $e)
    {
        if ($this instanceof ControlsAndContent) {
            $this->content()->add(Error::show($e));
        } else {
            echo $e->getMessage() . "\n";
            echo $e->getTraceAsString();
        }
    }
}
