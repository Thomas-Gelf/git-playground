<?php

namespace Icinga\Module\Metrics\Svg;

class SvgString
{
    public static function decode($svg)
    {
        return str_replace([
            '',
            '',
            '%27', // urlencode("'"),
            "'",
            '%3C', // urlencode('<'),
            '%3E', // urlencode('>'),
            '%23', // urlencode('#'),
        ], [
            "\r",
            "\n",
            "'",
            '"',
            '<',
            '>',
            '#',
        ], $svg);
    }
}
