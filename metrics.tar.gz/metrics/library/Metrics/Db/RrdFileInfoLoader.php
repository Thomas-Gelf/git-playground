<?php

namespace Icinga\Module\Metrics\Db;

use gipfl\RrdTool\Ds;
use gipfl\RrdTool\DsList;
use gipfl\RrdTool\RraSet;
use gipfl\RrdTool\RrdInfo;
use gipfl\ZfDb\Adapter\Pdo\PdoAdapter;
use gipfl\ZfDb\Adapter\Pdo\Pgsql;
use gipfl\ZfDb\Expr;
use Icinga\Module\Metrics\Ci;
use Icinga\Module\Metrics\ExtendedRrdInfo;
use Ramsey\Uuid\Uuid;
use Ramsey\Uuid\UuidInterface;

class RrdFileInfoLoader
{
    protected PdoAdapter $db;

    public function __construct(PdoAdapter $db)
    {
        $this->db = $db;
    }

    protected function loadCi(UuidInterface $uuid): Ci
    {
        $row = $this->fetchRowByUuid('ci', $uuid);
        return new Ci($row->hostname, $row->subject, $row->instance);
    }

    protected function fetchRraSet(string $binaryChecksum): RraSet
    {
        $rows = $this->fetchAll('rrd_archive', 'rrd_archive_set_checksum', $binaryChecksum, 'rra_index');
        $rraList = [];
        foreach ($rows as $row) {
            $rraList[] = $row->settings; // raw RRA definition
        }

        return new RraSet($rraList);
    }

    protected function fetchDsList(string $binaryChecksum): DsList
    {
        $dsRows = $this->fetchAll('rrd_datasource', 'datasource_list_checksum', $binaryChecksum, 'datasource_index');
        $dsList = new DsList();
        foreach ($dsRows as $row) {
            $dsList->add(new Ds(
                $row->datasource_name,
                $row->datasource_type,
                $row->minimal_heartbeat,
                $row->min_value,
                $row->max_value
            ));
        }

        return $dsList;
    }

    public function load(UuidInterface $fileUuid): ExtendedRrdInfo
    {
        $row = $this->fetchRowByUuid('rrd_file', $fileUuid);
        if ($row) {
            return $this->prepareInfoForFileRows([$row])[$fileUuid->getBytes()];
        }

        throw new \RuntimeException('Got no RRD file with UUID=' . $fileUuid->toString());
    }

    /**
     * @param array $rows
     * @return ExtendedRrdInfo[]
     */
    public function prepareInfoForFileRows(array $rows): array
    {
        /** @var RraSet[] $rraSets */
        $rraSets = [];
        /** @var DsList[] $dsLists */
        $dsLists = [];
        /** @var RrdInfo[] $result */
        $result = [];
        foreach ($rows as $row) {
            $uuid = Uuid::fromBytes($row->uuid);
            if (isset($row->hostname)) { // row with CI info
                $ci = new Ci($row->hostname, $row->subject, $row->instance);
            } else {
                $ci = $this->loadCi(Uuid::fromBytes($row->ci_uuid));
            }
            $dsListChecksum = $row->rrd_datasource_list_checksum;
            $rraSetChecksum = $row->rrd_archive_set_checksum;
            $rraSet = $rraSets[$rraSetChecksum] ?? $rraSets[$rraSetChecksum] = $this->fetchRraSet($rraSetChecksum);
            $dsList = $dsLists[$dsListChecksum] ?? $dsLists[$dsListChecksum] = $this->fetchDsList($dsListChecksum);
            $info = new ExtendedRrdInfo($uuid, $row->filename, $row->rrd_step, $dsList, $rraSet, $ci);
            $info->setHeaderSize($row->rrd_header_size ?: 0); // TODO: We need to fill this!!
            $result[$row->uuid] = $info;
        }

        return $result;
    }

    protected function fetchRowByUuid($table, UuidInterface $uuid, $uuidColumn = 'uuid')
    {
        $db = $this->db;
        return $db->fetchRow($db->select()->from($table)->where("$uuidColumn = ?", $this->hexUuid($uuid)));
    }

    protected function fetchAll($table, $keyColumn, $keyValue, $order = null): array
    {
        $db = $this->db;
        if (is_array($keyValue) && count($keyValue) === 1) {
            $keyValue = $keyValue[0];
        }
        $query = $db->select()->from($table);
        if (is_array($keyValue)) {
            foreach ($keyValue as &$value) {
                $value = $this->hexLiteral($value);
            }
            $query->where("$keyColumn IN (?)", $keyValue);
        } else {
            $query->where("$keyColumn = ?", $this->hexLiteral($keyValue));
        }
        if ($order !== null) {
            $query->order($order);
        }
        return $db->fetchAll($query);
    }

    protected function hexUuid(UuidInterface $uuid): Expr
    {
        return $this->hexLiteral($uuid->getBytes());
    }

    protected function hexLiteral(string $binary): Expr
    {
        if ($this->db instanceof Pgsql) {
            return new Expr("'\\x" . bin2hex($binary) . "'");
        }

        return new Expr('0x' . bin2hex($binary));
    }
}
