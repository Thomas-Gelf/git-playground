<?php

namespace Icinga\Module\Metrics\Web;

class RrdFormat
{
    public static function seconds($value)
    {
        $steps = [
            86400 => 'd',
            3600 => 'h',
            60 => 'm',
        ];

        $remain = $value;
        $parts = [];
        foreach ($steps as $div => $unit) {
            if ($remain > $div) {
                $current = \floor($remain / $div);
                $remain = $remain % $div;
                $parts[] = "$current$unit";
            }
        }
        if ($remain > 0) {
            $parts[] = $remain . 's';
        }

        return \implode(' ', $parts);
    }

    public static function number($number)
    {
        $locale = \localeconv();
        return \number_format(
            $number,
            $locale['frac_digits'],
            $locale['decimal_point'],
            $locale['thousands_sep']
        );
    }

    public static function percent($value)
    {
        return sprintf('%.2g%%', $value * 100);
    }
}
