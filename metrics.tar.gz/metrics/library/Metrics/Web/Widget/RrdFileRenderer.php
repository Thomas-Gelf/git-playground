<?php

namespace Icinga\Module\Metrics\Web\Widget;

use gipfl\IcingaWeb2\Url;
use gipfl\Translation\TranslationHelper;
use gipfl\Web\Widget\Hint;
use Icinga\Module\Metrics\Async\Infrastructure;
use Icinga\Module\Metrics\Rpc\RemoteClient;
use Icinga\Module\Metrics\ExtendedRrdInfo;
use Icinga\Module\Metrics\Template\TemplateFinder;
use ipl\Html\Html;
use ipl\Html\HtmlDocument;

class RrdFileRenderer extends HtmlDocument
{
    use TranslationHelper;

    protected int $width;
    protected int $height;
    protected int $start;
    protected int $end;
    protected int $limit = 5;
    protected ?Url $actionsUrl = null;
    protected ExtendedRrdInfo $fileInfo;
    protected ?RemoteClient $remoteClient = null;

    public function __construct(ExtendedRrdInfo $info, $width, $height)
    {
        $this->fileInfo = $info;
        $this->width = $width;
        $this->height = $height;
        $this->start = time() - 7200;
        $this->end = time();
    }

    public function setRemoteClient(RemoteClient $client): RrdFileRenderer
    {
        $this->remoteClient = $client;
        return $this;
    }

    public function showActionsFor(Url $url): RrdFileRenderer
    {
        $this->actionsUrl = $url;
        return $this;
    }

    public function setLimit(int $limit): self
    {
        $this->limit = $limit;

        return $this;
    }

    public function setStart(int $start): self
    {
        $this->start = $start;

        return $this;
    }

    public function setEnd(int $end): self
    {
        $this->end = $end;

        return $this;
    }

    protected function assemble()
    {
        $filename = $this->fileInfo->getFilename();
        if ($templates = TemplateFinder::findTemplate($this->fileInfo)) {
            $cnt = 0;
            foreach ($templates as $template) {
                $cnt++;
                $this->addImg(
                    new RrdImg($filename, $template, $this->width, $this->height, [
                        'disableCached' => true,
                        'start' => $this->start,
                        'end'   => $this->end,
                    ])
                );
                if ($cnt >= $this->limit) {
                    break;
                }
            }
        } else {
            $cnt = 0;
            foreach ($this->fileInfo->getDsList()->getDataSources() as $dsInfo) {
                $cnt++;
                $this->add(Html::tag('h3', $dsInfo->getName()));// Label?
                $this->addImg(new RrdImg($filename, 'default', $this->width, $this->height, [
                    'ds' => $dsInfo->getName(),
                    'smoke' => true,
                    'disableCached' => true,
                    'start' => $this->start,
                    'end'   => $this->end,
                ]));
                if ($cnt >= $this->limit) {
                    break;
                }
            }
        }
    }

    protected function addImg(RrdImg $img)
    {
        $this->optionallyLoadImmediately($img);
        $img->add(Hint::info(ImageDescription::forImage($img))->addAttributes(['class' => 'description']));
        if ($this->actionsUrl) {
            $this->add(new ImageActions($img, $this->fileInfo, $this->actionsUrl));
        }
        $this->add($img);
    }

    protected function optionallyLoadImmediately(RrdImg $img): RrdImg
    {
        if ($this->remoteClient) {
            $img->loadImmediately($this->remoteClient, Infrastructure::loop(), true);
        }

        return $img;
    }
}
