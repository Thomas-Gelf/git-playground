<?php

namespace Icinga\Module\Metrics\Web\Widget;

use Icinga\Module\Metrics\ExtendedRrdInfo;
use Icinga\Module\Metrics\Template\RrdCachedOperations;
use ipl\Html\Html;

class RrdCacheOperationsWidget extends BunchOfImages
{
    protected ExtendedRrdInfo $info;

    public function __construct(ExtendedRrdInfo $info)
    {
        $this->info = $info;
    }

    protected function assemble()
    {
        $this->addTitle('RRDCacheD Operations (per second)', 'chart-line');
        $this->add(new RrdLegend(new RrdCachedOperations()));
        $this->add(Html::tag('div', [
            'style' => 'width: 18em; display: inline-block;'
        ], [
            $this->linkToFile(
                $this->info,
                new RrdImg($this->info->getFilename(), 'RRDCacheDUpdates', 440, 180)
            )
        ]));
    }
}
