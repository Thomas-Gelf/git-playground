<?php

namespace Icinga\Module\Metrics\Web\Widget;

use gipfl\IcingaWeb2\Icon;
use gipfl\Translation\TranslationHelper;
use ipl\Html\Html;
use ipl\Html\HtmlDocument;

class CommandRenderer extends HtmlDocument
{
    use TranslationHelper;

    protected string $commandString;

    public function __construct(string $commandString)
    {
        $this->commandString = $commandString;
    }

    protected function assemble()
    {
        $icon = Icon::create('paste', [
            'onclick' => 'navigator.clipboard.writeText($(\'.content pre\').text().replace(/\r?\n/gs, \' \'))',
            'class'   => 'clipboard-icon',
            'title'   => $this->translate('Copy to Clipboard'),
        ]);
        $this->add(
            Html::tag('pre', [$icon, wordwrap($this->commandString, 80)])
        );
    }
}
