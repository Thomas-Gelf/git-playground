<?php

namespace Icinga\Module\Metrics\Web\Widget;

use ipl\Html\HtmlDocument;

class ImageDescription
{
    public static function forImage(RrdImg $img): ?HtmlDocument
    {
        $props = $img->getLoaded();
        if (isset($props->print->Transmitted)) {
            return new TrafficExtraInfo(
                $props->print->Received,
                $props->print->Transmitted,
                $props->graph->start,
                $props->graph->end
            );
        }

        return null;
    }
}
