<?php

namespace Icinga\Module\Metrics\Web\Widget;

use gipfl\Translation\TranslationHelper;
use Icinga\Date\DateFormatter;
use Icinga\Util\Format;
use ipl\Html\BaseHtmlElement;
use ipl\Html\Html;

class TrafficExtraInfo extends BaseHtmlElement
{
    use TranslationHelper;

    protected $tag = 'span';

    protected $defaultAttributes = [
        'class' => 'traffic-summary'
    ];

    public function __construct($received, $transmitted, $start, $end)
    {
        if (is_string($received) && preg_match('/nan/', $received)) {
            return;
        }
        $this->add(Html::sprintf(
            'Received %s, transmitted %s in %s',
            Format::bytes($received),
            Format::bytes($transmitted),
            DateFormatter::formatDuration(
                $end - $start
            )
        ));
    }
}
