<?php

namespace Icinga\Module\Metrics\Web\Widget;

use ipl\Html\Html;
use Icinga\Module\Metrics\Template\RrdQueueProcessing;

class InfluxdbQueueWidget extends BunchOfImages
{
    protected function assemble()
    {
        $file = '000-icinga-rrd-node/RRDHealth';
        $this->addTitle('InfluxDB Input, shipped data (Bytes, per second)', 'chart-line');
        $this->add(new RrdLegend(new RrdQueueProcessing()));
        $this->add(Html::tag('div', [
            'style' => 'width: 18em; display: inline-block;'
        ], [
            $this->linkToFile(
                $file,
                new RrdImg($file, 'Default', 440, 180, [
                    'ds'  => 'bytes_influxdb',
                    'rra' => 'AVERAGE',
                    'smoke' => true,
                ])
            )
        ]));
    }
}
