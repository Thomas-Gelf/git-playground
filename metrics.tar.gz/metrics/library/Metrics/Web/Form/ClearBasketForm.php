<?php

namespace Icinga\Module\Metrics\Web\Form;

use gipfl\IcingaWeb2\Icon;
use gipfl\Translation\TranslationHelper;
use gipfl\Web\Form\Feature\NextConfirmCancel;
use gipfl\Web\InlineForm;
use Icinga\Module\Metrics\Basket;

class ClearBasketForm extends InlineForm
{
    use TranslationHelper;

    protected Basket $basket;

    public function __construct(Basket $basket)
    {
        $this->basket = $basket;
    }

    protected function assemble()
    {
        $this->add(Icon::create('cancel'));
        $confirm = new NextConfirmCancel(
            NextConfirmCancel::buttonNext($this->translate('Clear')),
            NextConfirmCancel::buttonConfirm($this->translate('YES, clear my basket')),
            NextConfirmCancel::buttonCancel($this->translate('Cancel'), [
                'formnovalidate' => true
            ])
        );
        $confirm->addToForm($this);
    }

    protected function onSuccess()
    {
        $this->basket->clear();
    }
}
