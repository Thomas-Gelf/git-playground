<?php

namespace Icinga\Module\Metrics\Web\Form;

use gipfl\Translation\TranslationHelper;
use gipfl\Web\InlineForm;

class InstanceSelectForm extends InlineForm
{
    use TranslationHelper;

    protected array $instances;
    protected $defaultDecoratorClass = null;
    protected $useCsrf = false;
    protected $useFormName = false;

    public function __construct(array $instances)
    {
        $this->setMethod('GET');
        $this->addAttributes([
            'data-base-target' => '_self'
        ]);
        $this->instances = $instances;
    }

    public function getInstance()
    {
        if ($this->hasBeenSent() && $this->isValid()) {
            return $this->getValue('metricsInstance');
        }

        return null;
    }

    protected function assemble()
    {
        $this->addElement('select', 'metricsInstance', [
            'options' => $this->instances,
            'class'   => 'autosubmit',
        ]);
    }
}
