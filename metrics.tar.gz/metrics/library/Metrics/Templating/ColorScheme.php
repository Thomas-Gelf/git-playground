<?php

namespace Icinga\Module\Metrics\Templating;

use gipfl\RrdTool\Graph\Color;

interface ColorScheme
{
    public function getNextColor(): Color;
}
