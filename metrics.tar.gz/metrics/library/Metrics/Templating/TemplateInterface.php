<?php

namespace Icinga\Module\Metrics\Templating;

interface TemplateInterface
{
    public function getName(): string;
}
