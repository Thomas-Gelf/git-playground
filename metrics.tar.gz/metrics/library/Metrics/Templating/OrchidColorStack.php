<?php

namespace Icinga\Module\Metrics\Templating;

class OrchidColorStack extends ColorStack
{
    protected static array $colors = [
        '#DDA0DD',
        '#DA70D6',
        '#BA55D3',
        '#9932CC',
    ];
}
