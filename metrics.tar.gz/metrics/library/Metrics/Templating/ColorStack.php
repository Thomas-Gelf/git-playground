<?php

namespace Icinga\Module\Metrics\Templating;

use gipfl\RrdTool\Graph\Color;
use function array_shift;

abstract class ColorStack implements ColorScheme
{
    protected static array $colors = [
        '#ff0000',
        '#00ff00',
        '#0000ff',
    ];

    protected array $stack = [];

    public function reset()
    {
        $this->stack = $this::$colors;
    }

    public function getNextColor(): Color
    {
        if (empty($this->stack)) {
            $this->reset();
        }
        return new Color(array_shift($this->stack));
    }
}
