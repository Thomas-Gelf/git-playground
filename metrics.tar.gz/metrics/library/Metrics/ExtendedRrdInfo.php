<?php

namespace Icinga\Module\Metrics;

use gipfl\RrdTool\DsList;
use gipfl\RrdTool\RraSet;
use gipfl\RrdTool\RrdInfo;
use Ramsey\Uuid\UuidInterface;

class ExtendedRrdInfo extends RrdInfo
{
    protected UuidInterface $uuid;
    protected Ci $ci;

    public function __construct(UuidInterface $uuid, string $filename, int $step, DsList $dsList, RraSet $rra, Ci $ci)
    {
        parent::__construct($filename, $step, $dsList, $rra);
        $this->uuid = $uuid;
        $this->ci = $ci;
    }

    public function getCi(): Ci
    {
        return $this->ci;
    }

    public function getUuid(): UuidInterface
    {
        return $this->uuid;
    }
}
