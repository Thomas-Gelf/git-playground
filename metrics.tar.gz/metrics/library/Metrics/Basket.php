<?php

namespace Icinga\Module\Metrics;

use gipfl\Json\JsonString;
use Icinga\Module\Metrics\Web\Widget\RrdImg;
use Icinga\Web\Session\SessionNamespace;

class Basket
{
    const SESSION_KEY = 'basketImgs';

    protected SessionNamespace $session;

    protected array $imgParams;

    public function __construct(SessionNamespace $session)
    {
        $this->session = $session;
        // Hint: encoding is not required, but an additional security measurement. We do not
        // want to be affected by potential (un)serialization issues related to Zend_Session
        $this->imgParams = JsonString::decodeOptional($session->get(self::SESSION_KEY)) ?? [];
    }

    public function isEmpty(): bool
    {
        return count($this->imgParams) === 0;
    }

    public function clear()
    {
        $this->session->delete(self::SESSION_KEY);
    }

    public function add(RrdImg $img)
    {
        $newParams = (object)[];
        foreach ($img->getUrl()->getParams()->toArray(false) as $key => $value) {
            $newParams->$key = urldecode($value);
        }

        $this->imgParams[] = $newParams;
        $this->session->set(self::SESSION_KEY, JsonString::encode($this->imgParams));
    }

    /**
     * @return RrdImg[]
     */
    public function getImages(): array
    {
        $imgList = [];
        foreach ($this->imgParams as $params) {
            $imgList[] = RrdImg::fromUrlParams((array) $params);
        }

        return $imgList;
    }
}
