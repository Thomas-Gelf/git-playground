<?php

$this->provideJsFile('rrd.js');
$this->provideHook('grapher');

require __DIR__ . '/vendor/autoload.php';
