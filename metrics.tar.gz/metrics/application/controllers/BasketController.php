<?php

namespace Icinga\Module\Metrics\Controllers;

use gipfl\IcingaWeb2\Url;
use gipfl\Web\Widget\Hint;
use Icinga\Module\Metrics\Basket;
use Icinga\Module\Metrics\Web\Form\ClearBasketForm;
use Icinga\Module\Metrics\Web\Widget\RrdImg;
use Icinga\Web\Notification;
use Icinga\Web\Session;

class BasketController extends ControllerBase
{
    public function indexAction()
    {
        $this->addSingleTab($this->translate('Basket'));
        $this->addTitle($this->translate('Graphs in my Basket'));
        $basket = $this->getBasket();
        $clear = new ClearBasketForm($basket);
        $clear->on($clear::ON_SUCCESS, function () {
            Notification::success($this->translate('Basket has been cleared'));
            $this->redirectNow($this->url());
        })->handleRequest($this->getServerRequest());
        if ($basket->isEmpty()) {
            $this->content()->add(Hint::info($this->translate(
                'Currently there is no Graph in your Basket'
            )));
            return;
        }

        $this->actions()->add($clear);
        foreach ($basket->getImages() as $image) {
            $this->content()->add($image);
        }
    }

    public function addAction()
    {
        $basket = $this->getBasket();
        list($url, $params) = $this->getParamsAndReferrer();
        foreach ($params as &$param) {
            $param = urldecode($param);
        }
        $basket->add(RrdImg::fromUrlParams($params));
        Notification::success($this->translate('Graph has been added to your basket'));
        $this->redirectNow($url);
    }

    protected function getBasket(): Basket
    {
        $session = Session::getSession();
        $namespace = $session->getNamespace('metrics');

        return new Basket($namespace);
    }

    protected function getParamsAndReferrer(): array
    {
        $params = $this->url()->getParams()->toArray(false);
        $referrerUrl = urldecode($params['referrerUrl']);
        $referrerQueryString = urldecode($params['referrerQueryString']);
        $url = Url::fromPath($referrerUrl)->setQueryString($referrerQueryString);
        unset($params['referrerUrl']);
        unset($params['referrerQueryString']);
        return [$url, $params];
    }
}
