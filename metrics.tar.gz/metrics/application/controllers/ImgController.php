<?php

namespace Icinga\Module\Metrics\Controllers;

use Icinga\Module\Metrics\Svg\SvgString;
use Icinga\Module\Metrics\Web\ResponseSender;
use Icinga\Module\Metrics\Web\Widget\CommandRenderer;
use Icinga\Module\Metrics\Web\Widget\ImgRenderer;
use Icinga\Module\Metrics\Web\Widget\TrafficExtraInfo;
use function strpos;
use function substr;

class ImgController extends ControllerBase
{
    public function indexAction()
    {
        $this->sendImg();
    }

    public function sendImg()
    {
        $sender = new ResponseSender($this->getResponse());
        if ($this->isXhr()) {
            $sender->useXhr();
        }

        try {
            $img = ImgRenderer::fromUrlParams($this->params);
            if ($this->wantsCommand()) {
                $this->showCommand($img->getCommandString());
                return;
            }
            $this->preventZfLayout();

            $props = $this->syncRpcCall('rrd.graph', [
                'command' => $img->getCommandString(),
                'format'  => \strtoupper($img->getFormat()),
            ]);
            $props->print = (object) $img->getLastGraph()->translatePrintLabels($props->print);

            if ($this->isXhr() || $this->wantsJson()) {
                $this->addExtraInfos($props);
                $sender->sendAsJson($props);
            } else {
                $raw = $props->raw;
                if ($img->getFormat() === 'svg') {
                    $image = SvgString::decode(substr($raw, strpos($raw, ',') + 1));
                } else {
                    $image = \base64_decode(substr($raw, strpos($raw, ',') + 1));
                }
                if ($this->wantsDownload()) {
                    $sender->sendImage($image, $props->type, 'icinga-img.' . $img->getFormat());
                } else {
                    $sender->sendImage($image, $props->type);
                }
            }
        } catch (\Exception $e) {
            $sender->sendError($e, $this->getWidth(), $this->getHeight());
        }
    }

    protected function showCommand($command)
    {
        $this->assertPermission('metrics/admin');
        $this->addSingleTab('Img');
        $this->addTitle('Graph Rendering - Command');
        $this->content()->add(new CommandRenderer($command));
    }

    protected function wantsJson(): bool
    {
        return (bool) $this->params->get('wantJson');
    }

    protected function wantsCommand(): bool
    {
        return (bool) $this->params->get('showCommand');
    }

    protected function wantsDownload(): bool
    {
        return (bool) $this->params->get('download');
    }

    protected function getWidth(): int
    {
        return (int) $this->params->get('width', 1200);
    }

    protected function getHeight(): int
    {
        return (int) $this->params->get('height', 120);
    }

    protected function addExtraInfos($props)
    {
        if (isset($props->print->Transmitted)) {
            $props->title = (new TrafficExtraInfo(
                $props->print->Received,
                $props->print->Transmitted,
                $props->graph->start,
                $props->graph->end
            ))->render();
        }
    }

    protected function preventZfLayout()
    {
        $this->_helper->getHelper('layout')->disableLayout();
        $this->getViewRenderer()->disable();
    }
}
