<?php

namespace Icinga\Module\Metrics\Controllers;

use gipfl\IcingaWeb2\Link;
use gipfl\IcingaWeb2\Widget\Tabs;
use gipfl\RrdTool\RrdInfo;
use gipfl\Web\Widget\Hint;
use Icinga\Module\Metrics\Async\Infrastructure;
use Icinga\Module\Metrics\Db\RrdFileInfoLoader;
use Icinga\Module\Metrics\ExtendedRrdInfo;
use Icinga\Module\Metrics\Web\Table\DsInfoTable;
use Icinga\Module\Metrics\Web\Table\FileInfoTable;
use Icinga\Module\Metrics\Web\Table\RraInfoByDurationTable;
use Icinga\Module\Metrics\Web\Table\RraInfoTable;
use Icinga\Module\Metrics\Web\Widget\FileActions;
use Icinga\Module\Metrics\Web\Widget\RrdFileRenderer;
use ipl\Html\Html;
use Icinga\Application\Benchmark;
use Ramsey\Uuid\Uuid;
use Ramsey\Uuid\UuidInterface;

class RraController extends ControllerBase
{
    protected ?ExtendedRrdInfo $info = null;
    protected ?array $pending = null;

    public function init()
    {
        $info = $this->requireInfo();
        $filename = $info->getFilename();
        if ($this->getRequest()->getActionName() !== 'forgotten') {
            $actions = new FileActions($this->url(), $filename);
            if ($url = $actions->eventuallyRun(Infrastructure::remoteClient($this->db()), Infrastructure::loop())) {
                $this->redirectNow($url);
            }
            if ($this->getRequest()->getActionName() !== 'graph') {
                $this->actions()->add($actions);
            }
            try {
                $this->pending = $this->syncRpcCall('rrd.pending', [
                    'file' => $filename
                ]);
            } catch (\Throwable $e) {
                $this->content()->add(Hint::warning($e->getMessage()));
            }
        }

        if ($this->getRequest()->getActionName() !== 'graph') {
            $this->addTitle('RRD File: %s', $filename);
        }
        $this->fileTabs($info->getUuid());
    }

    public function graphAction()
    {
        $info = $this->requireInfo();
        $ci = $info->getCi();
        $this->addTitle(implode(' - ', array_filter([
            $ci->getHostname(),
            $ci->getSubject(),
            $ci->getInstance()
        ], function ($value) {
            return $value !== null;
        })));
        $this->content()->add([
            (new RrdFileRenderer($info, 640, 320))
                ->setRemoteClient(Infrastructure::remoteClient($this->db()))
                ->showActionsFor($this->url())
                ->setEnd($end = floor(time() / 60) * 60)
                ->setStart($end - 15 * 86400 * 7)
        ]);
    }

    public function fileAction()
    {
        $info = $this->requireInfo();
        $filename = $info->getFilename();
        $rp = ['file' => $filename];
        Benchmark::measure('Fetching essential data');
        $last = $this->optionallyGetLast($rp);
        $first = $this->syncRpcCall('rrd.first', $rp + ['rra' => 0]);
        $oldest = $this->syncRpcCall('rrd.first', [
            'file' => $filename,
            'rra'  => $info->getRraSet()->getIndexForLongestRra()
        ]);
        Benchmark::measure('Got basic infos');
        $this->content()->add([
            new FileInfoTable($info, $first, $oldest, $last),
        ]);
    }

    public function datasourcesAction()
    {
        $info = $this->requireInfo();
        $filename = $info->getFilename();
        $rp = ['file' => $filename];
        $last = $this->optionallyGetLast($rp);
        $oldest = $this->syncRpcCall('rrd.first', [
            'file' => $filename,
            'rra'  => $info->getRraSet()->getIndexForLongestRra()
        ]);
        // $summary = $this->getSummary($info, $oldest, $last);
        $summary = null;
        $this->content()->add([
            Html::tag('h2', $this->translate('Data Sources (DS)')),
            new DsInfoTable($info, $summary, $oldest, $last),
        ]);
    }

    public function archivesAction()
    {
        $info = $this->requireInfo();
        $this->content()->add([
            Html::tag('h2', $this->translate('Round Robin Archives (RRA)')),
            new RraInfoTable($info),
            Html::tag('h2', $this->translate('Archives by Duration')),
            new RraInfoByDurationTable($info),
        ]);
    }

    public function pendingAction()
    {
        $pending = $this->pending;
        $this->setAutorefreshInterval(10);
        $this->content()->add(Html::tag('h2', 'Pending'));
        if ($pending === null) {
            $this->content()->add('No updates are pending for this file');
        } elseif (empty($pending)) {
            $this->content()->add('No updates are pending for this file');
        } else {
            $this->content()->add(sprintf('%d pending update(s)', \count($pending)));
            $this->content()->add(Html::tag('pre', [
                'style' => 'max-height: 30em;'
            ], \is_array($pending) ? \implode("\n", array_reverse($pending)) : \var_export($pending, 1)));
        }
    }

    public function forgottenAction()
    {
        $filename = $this->requireInfo()->getFilename();
        $this->content()->add(Html::tag('p', [
            'class' => 'information'
        ], Html::sprintf(
            '%s has been removed from RRDCacheD. You can go %s to the file,'
            . ' it will then once again be loaded into RRDCacheD',
            $filename,
            Link::create(
                'back',
                'metrics/rra/file',
                ['filename' => $filename]
            )
        )));
    }

    public function deletedAction()
    {
        $filename = $this->requireInfo()->getFilename();
        $this->content()->add(Html::tag('p', [
            'class' => 'information'
        ], Html::sprintf(
            '%s has been deleted and removed from RRDCacheD',
            $filename
        )));
    }

    protected function requireInfo(): ExtendedRrdInfo
    {
        if ($this->info === null) {
            $this->info = $this->getFileInfoForUuid(Uuid::fromString($this->params->getRequired('uuid')));
        }

        return $this->info;
    }

    protected function getFileInfoForUuid(UuidInterface $uuid): ExtendedRrdInfo
    {
        $loader = new RrdFileInfoLoader($this->db());

        return $loader->load($uuid);
    }

    protected function getSummary(RrdInfo $fileInfo, $start, $end)
    {
        $files = [$fileInfo->getFilename()];
        $dsNames = $fileInfo->listDsNames();

        return $this->syncRpcCall('rrd.calculate', [
            'files' => $files,
            'dsNames' => $dsNames,
            'start' => $start,
            'end'   => $end,
        ]);
    }

    protected function optionallyGetLast($rp)
    {
        try {
            $last = $this->syncRpcCall('rrd.last', $rp);
        } catch (\Exception $e) {
            $this->content()->add(Html::tag('p', ['class' => 'error'], 'LAST failed: ' . $e->getMessage()));
            $last = null;
        }

        return $last;
    }

    protected function fileTabs(UuidInterface $uuid): Tabs
    {
        if ($this->pending === null) {
            $pendingTitle = $this->translate('Pending');
        } else {
            $pendingTitle = sprintf(
                $this->translate('Pending (%d)'),
                count($this->pending)
            );
        }
        $params = [
            'uuid' => $uuid->toString()
        ];
        $tabs = $this->tabs()->add('graph', [
            'label'     => $this->translate('Graph'),
            'url'       => 'metrics/rra/graph',
            'urlParams' => $params,
        ])->add('file', [
            'label'     => $this->translate('File Info'),
            'url'       => 'metrics/rra/file',
            'urlParams' => $params,
        ])->add('datasources', [
            'label'     => $this->translate('Data Sources'),
            'url'       => 'metrics/rra/datasources',
            'urlParams' => $params,
        ])->add('archives', [
            'label'     => $this->translate('Archives'),
            'url'       => 'metrics/rra/archives',
            'urlParams' => $params,
        ])->add('pending', [
            'label'     => $pendingTitle,
            'url'       => 'metrics/rra/pending',
            'urlParams' => $params,
        ]);
        $action = $this->getRequest()->getActionName();
        if ($action === 'forgotten' || $action === 'deleted') {
            $action = 'file';
        }
        $tabs->activate($action);

        return $tabs;
    }
}
