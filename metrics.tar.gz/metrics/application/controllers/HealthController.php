<?php

namespace Icinga\Module\Metrics\Controllers;

use gipfl\IcingaWeb2\Icon;
use gipfl\Web\Widget\Hint;
use gipfl\ZfDb\Select;
use Icinga\Module\Metrics\Db\RrdFileInfoLoader;
use Icinga\Module\Metrics\ExtendedRrdInfo;
use Icinga\Module\Metrics\Web\Widget\CpuUsage;
use Icinga\Module\Metrics\Web\Widget\InterfaceMetrics;
use Icinga\Module\Metrics\Web\Widget\RrdCacheOperationsWidget;
use Icinga\Module\Metrics\Web\Widget\RrdQueueProcessingWidget;
use ipl\Html\Html;

class HealthController extends ControllerBase
{
    public function indexAction()
    {
        $this->setAutorefreshInterval(600);
        $this->addSingleTab($this->translate('Metrics Health'));
        $this->setTitle('Health Info');
        try {
            $this->addHealthInfo();
        } catch (\Exception $exception) {
            $this->setAutorefreshInterval(15);
            $this->controls()->add(Html::tag('h1', [
                Icon::create('bug'),
                $this->translate('Oops, an error occurred!')
            ]));
            $this->content()->add(Hint::error($exception->getMessage()));
        }
    }

    protected function prepareMetricStoreFilesQuery(string $subject, $columns = []): Select
    {
        return $this->db()->select()
            ->from(['rf' => 'rrd_file'], $columns)
            ->join('ci', 'ci.uuid = rf.ci_uuid', [])
            ->where('hostname = ?', $this->getMetricStoreUuid()->toString())
            ->where('subject = ?', $subject)
            ->order('ci.instance');
    }

    /**
     * @param $subject
     * @return ExtendedRrdInfo[]
     */
    protected function fetchMetricStoreFilesInfo(string $subject): array
    {
        $loader = new RrdFileInfoLoader($this->db());
        return $loader->prepareInfoForFileRows(
            $this->db()->fetchAll($this->prepareMetricStoreFilesQuery($subject, ['*', 'rf.uuid']))
        );
    }

    protected function prepareMetricStoreFileQuery(string $subject, $columns = []): Select
    {
        return $this->db()->select()
            ->from(['rf' => 'rrd_file'])
            ->join('ci', 'ci.uuid = rf.ci_uuid', $columns)
            ->where('hostname = ?', $this->getMetricStoreUuid()->toString())
            ->where('subject = ?', $subject);
    }

    protected function fetchMetricStoreFileInfo($subject): ExtendedRrdInfo
    {
        $loader = new RrdFileInfoLoader($this->db());
        $infos = $loader->prepareInfoForFileRows([$this->fetchMetricStoreFile($subject, ['*', 'rf.uuid'])]);
        return array_shift($infos);
    }

    protected function fetchMetricStoreFile($subject, $columns)
    {
        $db = $this->db();
        $result = $db->fetchAll($this->prepareMetricStoreFileQuery($subject, $columns));

        if (empty($result)) {
            return null;
        }

        return array_shift($result);
    }

    protected function addHealthInfo()
    {
        $cpus = $this->fetchMetricStoreFilesInfo('CPU');
        $interfaces = $this->fetchMetricStoreFilesInfo('Interface');
        $max = $this->getMaxCpuUsage($cpus);

        $rrdHealth = $this->fetchMetricStoreFileInfo('RRDHealth');
        $rrdCacheD = $this->fetchMetricStoreFileInfo('RRDCacheD');
        $this->content()->add([
            Html::tag('div', [
                'style' => 'width: 32em; display: inline-block; vertical-align: top; overflow: hidden;'
                . ' float: left; margin-right: 1em;'
            ], (new CpuUsage($cpus, 'size3'))->setMax($max)),
            Html::tag('div', [
                'style' => 'max-width: 72em; display: block; vertical-align: top; overflow: hidden; float: left;'
            ], [
                new RrdQueueProcessingWidget($rrdHealth),
                new RrdCacheOperationsWidget($rrdCacheD),
                new InterfaceMetrics($interfaces),
                // new InfluxdbQueueWidget(),
            ]),
        ]);
    }

    /**
     * @param ExtendedRrdInfo[] $cpus
     * @return int
     * @throws \Exception
     */
    protected function getMaxCpuUsage(array $cpus)
    {
        $cpuFiles = [];
        foreach ($cpus as $cpu) {
            $cpuFiles[] = $cpu->getFilename();
        }
        $cpuInfo = $this->syncRpcCall('rrd.calculate', [
            'files' => $cpuFiles,
            'dsNames' => [
                'guest',
                'guest_nice',
                'idle',
                'iowait',
                'irq',
                'nice',
                'steal',
                'system',
                'user',
            ],
            'start' => time() - 3600,
            'end'   => time(),
        ]);
        $max = 0;
        foreach ($cpuInfo as $info) {
            $sum = $info->guest->maxavg_value
                +  $info->guest_nice->maxavg_value
                +  $info->iowait->maxavg_value
                +  $info->irq->maxavg_value
                +  $info->nice->maxavg_value
                +  $info->steal->maxavg_value
                +  $info->system->maxavg_value
                +  $info->user->maxavg_value;
            $max = max($max, $sum);
        }

        return (int) (round($max / 4) * 4);
    }
}
