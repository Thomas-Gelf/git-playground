<?php

namespace Icinga\Module\Metrics\Controllers;

use Icinga\Module\Metrics\Web\Table\DbFilesTable;

class FilesController extends ControllerBase
{
    public function indexAction()
    {
        $this->addSingleTab('Remote RRD Files');
        $this->addTitle('RRD Experiments - All files');
        $table = new DbFilesTable($this->db());
        $table->renderTo($this);
    }
}
