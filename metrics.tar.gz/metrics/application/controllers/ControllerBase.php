<?php

namespace Icinga\Module\Metrics\Controllers;

use gipfl\IcingaWeb2\CompatController;
use gipfl\ZfDb\Adapter\Pdo\PdoAdapter;
use Icinga\Module\Metrics\Async\Infrastructure;
use Icinga\Module\Metrics\Db\DbFactory;
use Ramsey\Uuid\Uuid;
use Ramsey\Uuid\UuidInterface;

abstract class ControllerBase extends CompatController
{
    protected ?PdoAdapter $db = null;

    protected function getMetricStoreUuid(): UuidInterface
    {
        $db = $this->db();
        return Uuid::fromBytes(
            $db->fetchOne($db->select()->from('metric_store', 'uuid')->where('label = ?', 'benchmark'))
        );
    }

    /**
     * @param $method
     * @param $params
     * @return mixed|null
     * @throws \Exception
     */
    protected function syncRpcCall($method, $params)
    {
        return Infrastructure::syncRpcCall($this->db(), $method, $params);
    }

    protected function db(): PdoAdapter
    {
        if ($this->db === null) {
            $this->db = DbFactory::db();
        }

        return $this->db;
    }
}
